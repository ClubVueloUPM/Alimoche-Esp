package main

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"
)

var (
	apiBase     = "https://api.github.com"
	httpc       = &http.Client{Timeout: 25 * time.Second}
	tokenActual string
)

type apiError struct {
	Status int
	Msg    string
}

func (e *apiError) Error() string { return e.Msg }

// api hace una llamada a la API REST de GitHub con el token del usuario.
func api(method, path string, body interface{}, out interface{}) (int, error) {
	if tokenActual == "" {
		return 0, errors.New("no hay token de GitHub guardado. Pulsa «Cuenta» → «Cambiar token»")
	}
	var rd io.Reader
	if body != nil {
		b, _ := json.Marshal(body)
		rd = bytes.NewReader(b)
	}
	req, err := http.NewRequest(method, apiBase+path, rd)
	if err != nil {
		return 0, err
	}
	req.Header.Set("Authorization", "Bearer "+tokenActual)
	req.Header.Set("Accept", "application/vnd.github+json")
	req.Header.Set("X-GitHub-Api-Version", "2022-11-28")
	req.Header.Set("User-Agent", "ALIMOCHE-Git/"+version)
	if body != nil {
		req.Header.Set("Content-Type", "application/json")
	}
	resp, err := httpc.Do(req)
	if err != nil {
		return 0, errors.New("no hay conexión con GitHub. Revisa internet y vuelve a intentarlo")
	}
	defer resp.Body.Close()
	data, _ := io.ReadAll(resp.Body)
	if resp.StatusCode >= 300 {
		var e struct {
			Message string `json:"message"`
			Errors  []struct {
				Message string `json:"message"`
			} `json:"errors"`
		}
		_ = json.Unmarshal(data, &e)
		msg := e.Message
		for _, x := range e.Errors {
			if x.Message != "" {
				msg += " — " + x.Message
			}
		}
		if resp.StatusCode == 401 {
			msg = "GitHub no acepta el token: es incorrecto, ha caducado o se ha revocado. Genera uno nuevo y pégalo en «Cuenta» → «Cambiar token»"
		}
		return resp.StatusCode, &apiError{resp.StatusCode, msg}
	}
	if out != nil && len(data) > 0 {
		if err := json.Unmarshal(data, out); err != nil {
			return resp.StatusCode, err
		}
	}
	return resp.StatusCode, nil
}

func ownerRepo(remote string) (string, string) {
	m := reGH.FindStringSubmatch(strings.TrimSpace(remote))
	if m == nil {
		return "", ""
	}
	return m[1], m[2]
}

// httpsGitHub normaliza cualquier dirección de GitHub (web, ssh, owner/repo) a https …/repo.git
func httpsGitHub(u string) string {
	u = strings.TrimSpace(u)
	if o, r := ownerRepo(u); o != "" {
		return "https://github.com/" + o + "/" + r + ".git"
	}
	if p := strings.Split(strings.Trim(u, "/"), "/"); len(p) == 2 && !strings.Contains(u, ":") && !strings.Contains(u, "\\") {
		return "https://github.com/" + p[0] + "/" + strings.TrimSuffix(p[1], ".git") + ".git"
	}
	return u
}

func esc(s string) string { return url.PathEscape(s) }

// ---------- usuario ----------

type ghUser struct {
	Login  string `json:"login"`
	ID     int64  `json:"id"`
	Name   string `json:"name"`
	Avatar string `json:"avatar_url"`
}

func usuario() (*ghUser, error) {
	var u ghUser
	if _, err := api("GET", "/user", nil, &u); err != nil {
		return nil, err
	}
	return &u, nil
}

func (u *ghUser) nombreAutor() string {
	if strings.TrimSpace(u.Name) != "" {
		return u.Name
	}
	return u.Login
}

// Correo "noreply" de GitHub: enlaza el commit a la cuenta sin exponer el correo real.
func (u *ghUser) correoAutor() string {
	return fmt.Sprintf("%d+%s@users.noreply.github.com", u.ID, u.Login)
}

// ---------- repositorio y permisos ----------

type ghRepo struct {
	FullName      string `json:"full_name"`
	DefaultBranch string `json:"default_branch"`
	HTMLURL       string `json:"html_url"`
	Private       bool   `json:"private"`
	Permissions   struct {
		Admin    bool `json:"admin"`
		Maintain bool `json:"maintain"`
		Push     bool `json:"push"`
		Pull     bool `json:"pull"`
	} `json:"permissions"`
}

func repoInfo(o, r string) (*ghRepo, error) {
	var g ghRepo
	st, err := api("GET", "/repos/"+esc(o)+"/"+esc(r), nil, &g)
	if err != nil {
		if st == 404 || st == 403 {
			return nil, fmt.Errorf("tu token no da acceso a %s/%s. Puede ser por: 1) al crear el token no marcaste este repositorio (edítalo en GitHub y añádelo en «Repository access»; sigue siendo el mismo token); 2) tu cuenta no tiene acceso a ese repositorio (pide al administrador que te añada); 3) la organización «%s» aún no ha aprobado tu token", o, r, o)
		}
		return nil, err
	}
	return &g, nil
}

type Permisos struct {
	Login               string `json:"login"`
	Nombre              string `json:"nombre"`
	Avatar              string `json:"avatar"`
	Repo                string `json:"repo"`
	Principal           string `json:"principal"`
	Escritura           bool   `json:"escritura"`
	Admin               bool   `json:"admin"`
	Directo             string `json:"directo"` // "si" | "no" | "?"
	IntegrarSinRevision bool   `json:"integrarSinRevision"`
	Rol                 string `json:"rol"`
	Explicacion         string `json:"explicacion"`
}

var bloqueantes = map[string]bool{
	"pull_request": true, "update": true, "required_status_checks": true,
	"required_deployments": true, "merge_queue": true,
}

// permisos averigua qué puede hacer la cuenta del token en la rama principal.
func permisos(o, r string) (*Permisos, error) {
	u, err := usuario()
	if err != nil {
		return nil, err
	}
	g, err := repoInfo(o, r)
	if err != nil {
		return nil, err
	}
	p := &Permisos{Login: u.Login, Nombre: u.nombreAutor(), Avatar: u.Avatar, Repo: g.FullName, Principal: g.DefaultBranch}
	p.Admin = g.Permissions.Admin
	p.Escritura = g.Permissions.Push || g.Permissions.Maintain || g.Permissions.Admin
	if !p.Escritura {
		p.Directo = "no"
		p.Rol = "Solo lectura"
		p.Explicacion = "Tu cuenta puede descargar y ver el repositorio, pero no subir cambios. Pide al administrador permiso de escritura."
		return p, nil
	}
	base := esc(g.DefaultBranch)

	// 1) Rulesets (reglas nuevas de GitHub, de repo o de organización)
	reglasBloquean, reglasIntegrar, reglasDesconocidas := false, true, false
	var rules []struct {
		Type      string `json:"type"`
		RulesetID int64  `json:"ruleset_id"`
	}
	if _, err := api("GET", "/repos/"+esc(o)+"/"+esc(r)+"/rules/branches/"+base, nil, &rules); err != nil {
		reglasDesconocidas = true
	} else {
		ids := map[int64]bool{}
		for _, x := range rules {
			if bloqueantes[x.Type] {
				ids[x.RulesetID] = true
			}
		}
		for id := range ids {
			var rs struct {
				Bypass string `json:"current_user_can_bypass"`
			}
			if _, err := api("GET", fmt.Sprintf("/repos/%s/%s/rulesets/%d?includes_parents=true", esc(o), esc(r), id), nil, &rs); err != nil {
				reglasDesconocidas = true
				reglasIntegrar = false
				continue
			}
			switch rs.Bypass {
			case "always", "exempt":
			case "pull_requests_only":
				reglasBloquean = true
			default:
				reglasBloquean = true
				reglasIntegrar = false
			}
		}
	}

	// 2) Protección clásica de rama
	clasicaBloquea, clasicaIntegrar, clasicaDesconocida := false, true, false
	var br struct {
		Protected bool `json:"protected"`
	}
	if _, err := api("GET", "/repos/"+esc(o)+"/"+esc(r)+"/branches/"+base, nil, &br); err == nil && br.Protected {
		var pr struct {
			RequiredPullRequestReviews *struct {
				Bypass struct {
					Users []struct {
						Login string `json:"login"`
					} `json:"users"`
				} `json:"bypass_pull_request_allowances"`
			} `json:"required_pull_request_reviews"`
			RequiredStatusChecks *json.RawMessage `json:"required_status_checks"`
			Restrictions         *json.RawMessage `json:"restrictions"`
			EnforceAdmins        struct {
				Enabled bool `json:"enabled"`
			} `json:"enforce_admins"`
		}
		st, err := api("GET", "/repos/"+esc(o)+"/"+esc(r)+"/branches/"+base+"/protection", nil, &pr)
		switch {
		case err == nil:
			bloquea := pr.RequiredPullRequestReviews != nil || pr.RequiredStatusChecks != nil || pr.Restrictions != nil
			enLista := false
			if pr.RequiredPullRequestReviews != nil {
				for _, x := range pr.RequiredPullRequestReviews.Bypass.Users {
					if strings.EqualFold(x.Login, u.Login) {
						enLista = true
					}
				}
			}
			saltaAdmin := p.Admin && !pr.EnforceAdmins.Enabled
			clasicaBloquea = bloquea && !saltaAdmin && !enLista
			clasicaIntegrar = !bloquea || saltaAdmin || enLista
		case st == 404:
			// la marca "protected" venía solo de los rulesets
		default:
			clasicaDesconocida = true
			clasicaIntegrar = p.Admin
		}
	}

	switch {
	case reglasBloquean || clasicaBloquea:
		p.Directo = "no"
	case reglasDesconocidas || clasicaDesconocida:
		p.Directo = "?"
	default:
		p.Directo = "si"
	}
	p.IntegrarSinRevision = reglasIntegrar && clasicaIntegrar

	switch {
	case p.Directo == "si":
		p.Rol = "Acceso directo a " + g.DefaultBranch
		p.Explicacion = "Tu cuenta puede subir directamente a " + g.DefaultBranch + " (bypass) e integrar propuestas sin esperar revisión."
	case p.Directo == "?":
		p.Rol = "Escritura"
		p.Explicacion = "No se ha podido leer toda la protección de " + g.DefaultBranch + " (a tu token le falta el permiso «Administration: read»). Si subes a " + g.DefaultBranch + " se intentará y, si GitHub lo rechaza, se convertirá en propuesta."
	default:
		p.Rol = "Miembro · por propuesta"
		p.Explicacion = "Tus cambios llegan a " + g.DefaultBranch + " mediante propuestas (pull requests) que revisa quien tiene permiso."
	}
	if p.IntegrarSinRevision && p.Directo != "si" {
		p.Explicacion += " Puedes integrar propuestas sin esperar la revisión."
	}
	return p, nil
}

// ---------- propuestas (pull requests) ----------

type ghPR struct {
	Number  int    `json:"number"`
	Title   string `json:"title"`
	Body    string `json:"body"`
	HTMLURL string `json:"html_url"`
	Draft   bool   `json:"draft"`
	Created string `json:"created_at"`
	User    struct {
		Login string `json:"login"`
	} `json:"user"`
	Head struct {
		Ref  string `json:"ref"`
		Repo *struct {
			FullName string `json:"full_name"`
		} `json:"repo"`
	} `json:"head"`
	Base struct {
		Ref string `json:"ref"`
	} `json:"base"`
}

func crearPR(o, r, base, rama, titulo, cuerpo string) (*ghPR, bool, error) {
	var pr ghPR
	st, err := api("POST", "/repos/"+esc(o)+"/"+esc(r)+"/pulls", map[string]string{
		"title": titulo, "head": rama, "base": base, "body": cuerpo,
	}, &pr)
	if err == nil {
		return &pr, false, nil
	}
	if st == 422 && strings.Contains(strings.ToLower(err.Error()), "already exists") {
		var l []ghPR
		q := url.Values{"state": {"open"}, "head": {o + ":" + rama}}
		if _, e2 := api("GET", "/repos/"+esc(o)+"/"+esc(r)+"/pulls?"+q.Encode(), nil, &l); e2 == nil && len(l) > 0 {
			return &l[0], true, nil
		}
	}
	if st == 422 && strings.Contains(strings.ToLower(err.Error()), "no commits between") {
		return nil, false, errors.New("tu rama no tiene nada distinto de " + base + ": no hay nada que proponer")
	}
	if st == 403 {
		return nil, false, errors.New("tu token no tiene permiso para crear propuestas. Al generarlo, pon «Pull requests» en «Read and write»")
	}
	return nil, false, err
}

func listarPRs(o, r string) ([]ghPR, error) {
	var l []ghPR
	_, err := api("GET", "/repos/"+esc(o)+"/"+esc(r)+"/pulls?state=open&per_page=50", nil, &l)
	return l, err
}

func integrarPR(o, r string, n int) (string, error) {
	var pr ghPR
	if _, err := api("GET", fmt.Sprintf("/repos/%s/%s/pulls/%d", esc(o), esc(r), n), nil, &pr); err != nil {
		return "", err
	}
	var res struct {
		Merged  bool   `json:"merged"`
		Message string `json:"message"`
	}
	st, err := api("PUT", fmt.Sprintf("/repos/%s/%s/pulls/%d/merge", esc(o), esc(r), n), map[string]string{
		"merge_method": "merge",
		"commit_title": fmt.Sprintf("Integrada propuesta #%d: %s", n, pr.Title),
	}, &res)
	if err != nil {
		switch st {
		case 405:
			return "", errors.New("GitHub no permite integrarla todavía: " + err.Error())
		case 409:
			return "", errors.New("la propuesta tiene conflictos con " + pr.Base.Ref + ". Quien la hizo debe pulsar «Actualizar con " + pr.Base.Ref + "», resolver y volver a subir")
		case 403:
			return "", errors.New("tu cuenta o tu token no tienen permiso para integrar propuestas")
		}
		return "", err
	}
	// borrar la rama ya integrada (si es de este repo)
	if pr.Head.Repo != nil && strings.EqualFold(pr.Head.Repo.FullName, o+"/"+r) && pr.Head.Ref != pr.Base.Ref {
		_, _ = api("DELETE", "/repos/"+esc(o)+"/"+esc(r)+"/git/refs/heads/"+pr.Head.Ref, nil, nil)
	}
	return fmt.Sprintf("Propuesta #%d integrada en %s.", n, pr.Base.Ref), nil
}

type repoItem struct {
	Nombre string `json:"nombre"`
	URL    string `json:"url"`
}

func listarRepos() ([]repoItem, error) {
	var l []struct {
		FullName string `json:"full_name"`
		HTMLURL  string `json:"html_url"`
	}
	if _, err := api("GET", "/user/repos?per_page=100&sort=updated", nil, &l); err != nil {
		return nil, err
	}
	res := []repoItem{}
	for _, x := range l {
		res = append(res, repoItem{x.FullName, x.HTMLURL})
	}
	return res, nil
}

// enlaceToken: página de GitHub para crear el token con todo rellenado.
func enlaceToken(owner string, admin bool) string {
	q := url.Values{}
	q.Set("name", "ALIMOCHE-Git")
	q.Set("description", "Token para el programa ALIMOCHE · Git (subir cambios y propuestas)")
	if owner != "" {
		q.Set("target_name", owner)
	}
	q.Set("expires_in", "366")
	q.Set("contents", "write")
	q.Set("pull_requests", "write")
	if admin {
		q.Set("administration", "read")
	}
	return "https://github.com/settings/personal-access-tokens/new?" + q.Encode()
}
