//go:build windows

package main

import (
	_ "embed"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"

	webview2 "github.com/jchv/go-webview2"
)

//go:embed ui.html
var uiHTML string

//go:embed logo.jpeg
var logo []byte

var w webview2.WebView

func emitLogWin(s string) {
	if w == nil {
		return
	}
	j, _ := json.Marshal(s)
	w.Dispatch(func() { w.Eval("window.__log && window.__log(" + string(j) + ")") })
}

func main() {
	loadCfg()
	logHook = emitLogWin
	gitExe = findGit()

	local := os.Getenv("LOCALAPPDATA")
	if local == "" {
		local = cfgDir
	}
	w = webview2.NewWithOptions(webview2.WebViewOptions{
		Debug:     false,
		AutoFocus: true,
		DataPath:  filepath.Join(local, "AlimocheGit", "webview"),
		WindowOptions: webview2.WindowOptions{
			Title:  "ALIMOCHE · Git",
			Width:  1100,
			Height: 760,
			IconId: 2,
			Center: true,
		},
	})
	if w == nil {
		msgBox("ALIMOCHE · Git", "No se ha podido abrir la ventana. Falta el componente Microsoft Edge WebView2 Runtime (viene con Windows 10/11 actualizado). Instálalo desde la web de Microsoft y vuelve a abrir el programa.")
		return
	}
	defer w.Destroy()
	w.SetSize(1100, 760, webview2.HintNone)

	_ = w.Bind("goCall", func(id int, op string, args map[string]interface{}) {
		go func() {
			opMu.Lock()
			res, err := handle(op, args)
			opMu.Unlock()
			payload := map[string]interface{}{"ok": err == nil, "data": res}
			if err != nil {
				msg := err.Error()
				payload["error"] = msg
				if e := explicar(msg); e != "" {
					payload["ayuda"] = e
				}
			}
			j, _ := json.Marshal(payload)
			w.Dispatch(func() { w.Eval(fmt.Sprintf("window.__done(%d,%s)", id, string(j))) })
		}()
	})

	html := strings.Replace(uiHTML, "{{LOGO}}", "data:image/jpeg;base64,"+base64.StdEncoding.EncodeToString(logo), 1)
	html = strings.Replace(html, "{{VERSION}}", version, -1)
	w.SetHtml(html)
	w.Run()
}
