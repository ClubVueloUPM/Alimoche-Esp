package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
)

func do(t *testing.T, op string, a map[string]interface{}) interface{} {
	t.Helper()
	r, err := handle(op, a)
	if err != nil {
		t.Fatalf("%s: error: %v (ayuda: %s)", op, err, explicar(err.Error()))
	}
	return r
}

func sh(t *testing.T, dir string, args ...string) {
	t.Helper()
	c := exec.Command(args[0], args[1:]...)
	c.Dir = dir
	if out, err := c.CombinedOutput(); err != nil {
		t.Fatalf("%v: %s", args, out)
	}
}

// GitHub simulado: dos tokens. "tok-miembro" (escritura, sin bypass) y
// "tok-admin" (admin con bypass "always" en el ruleset de main).
type fakeGH struct {
	prs    []map[string]interface{}
	merged []int
}

func (f *fakeGH) handler(t *testing.T) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		auth := r.Header.Get("Authorization")
		admin := auth == "Bearer tok-admin"
		if !admin && auth != "Bearer tok-miembro" {
			w.WriteHeader(401)
			w.Write([]byte(`{"message":"Bad credentials"}`))
			return
		}
		login, id := "miembro", 2
		if admin {
			login, id = "augusto", 1
		}
		js := func(v interface{}) { json.NewEncoder(w).Encode(v) }
		p := r.URL.Path
		switch {
		case p == "/user":
			js(map[string]interface{}{"login": login, "id": id, "name": strings.Title(login), "avatar_url": "x"})
		case p == "/repos/org/ALIMOCHE":
			js(map[string]interface{}{"full_name": "org/ALIMOCHE", "default_branch": "main",
				"permissions": map[string]bool{"admin": admin, "push": true, "pull": true}})
		case p == "/repos/org/ALIMOCHE/rules/branches/main":
			js([]map[string]interface{}{{"type": "pull_request", "ruleset_id": 7}, {"type": "deletion", "ruleset_id": 7}})
		case p == "/repos/org/ALIMOCHE/rulesets/7":
			b := "never"
			if admin {
				b = "always"
			}
			js(map[string]interface{}{"id": 7, "current_user_can_bypass": b})
		case p == "/repos/org/ALIMOCHE/branches/main":
			js(map[string]interface{}{"protected": true})
		case p == "/repos/org/ALIMOCHE/branches/main/protection":
			w.WriteHeader(404)
			w.Write([]byte(`{"message":"Branch not protected"}`))
		case p == "/repos/org/ALIMOCHE/pulls" && r.Method == "POST":
			var b map[string]string
			json.NewDecoder(r.Body).Decode(&b)
			n := len(f.prs) + 1
			pr := map[string]interface{}{"number": n, "title": b["title"], "body": b["body"], "html_url": fmt.Sprintf("https://github.com/org/ALIMOCHE/pull/%d", n),
				"user": map[string]string{"login": login}, "head": map[string]interface{}{"ref": b["head"], "repo": map[string]string{"full_name": "org/ALIMOCHE"}},
				"base": map[string]string{"ref": b["base"]}, "created_at": "2026-10-27T10:00:00Z"}
			f.prs = append(f.prs, pr)
			w.WriteHeader(201)
			js(pr)
		case p == "/repos/org/ALIMOCHE/pulls":
			js(f.prs)
		case strings.HasPrefix(p, "/repos/org/ALIMOCHE/pulls/") && strings.HasSuffix(p, "/merge"):
			if !admin {
				w.WriteHeader(405)
				w.Write([]byte(`{"message":"Pull request review is required"}`))
				return
			}
			f.merged = append(f.merged, 1)
			js(map[string]interface{}{"merged": true})
		case strings.HasPrefix(p, "/repos/org/ALIMOCHE/pulls/"):
			js(f.prs[0])
		case strings.HasPrefix(p, "/repos/org/ALIMOCHE/git/refs/heads/"):
			w.WriteHeader(204)
		default:
			t.Logf("API sin simular: %s %s", r.Method, p)
			w.WriteHeader(404)
			w.Write([]byte(`{"message":"Not Found"}`))
		}
	})
}

func TestFlujo(t *testing.T) {
	tmp := t.TempDir()
	os.Setenv("HOME", tmp)
	os.Setenv("APPDATA", filepath.Join(tmp, "appdata"))
	os.Setenv("GIT_CONFIG_NOSYSTEM", "1")
	logHook = func(s string) {
		if !strings.HasPrefix(s, "$ git") {
			fmt.Print("    │ " + strings.ReplaceAll(strings.TrimRight(s, "\n"), "\n", "\n    │ ") + "\n")
		}
	}
	gh := &fakeGH{}
	srv := httptest.NewServer(gh.handler(t))
	defer srv.Close()
	apiBase = srv.URL
	loadCfg()
	gitExe = findGit()

	// repositorio remoto local que se hace pasar por https://github.com/org/ALIMOCHE.git
	bare := filepath.Join(tmp, "remoto.git")
	sh(t, tmp, "git", "init", "-q", "--bare", "-b", "main", bare)
	sh(t, tmp, "git", "config", "--global", "url."+bare+".insteadOf", "https://github.com/org/ALIMOCHE.git")
	seed := filepath.Join(tmp, "seed")
	sh(t, tmp, "git", "clone", "-q", bare, seed)
	os.WriteFile(filepath.Join(seed, "README.md"), []byte("hola\n"), 0o644)
	sh(t, seed, "git", "-c", "user.name=a", "-c", "user.email=a@a", "add", ".")
	sh(t, seed, "git", "-c", "user.name=a", "-c", "user.email=a@a", "commit", "-qm", "inicio")
	sh(t, seed, "git", "push", "-q", "origin", "main")
	hook := "#!/bin/sh\nwhile read o n r; do [ \"$r\" = refs/heads/main ] && [ -z \"$PERMITIR\" ] && { echo 'remote: error: GH006: Protected branch update failed for refs/heads/main.' >&2; exit 1; }; done; exit 0\n"
	os.WriteFile(filepath.Join(bare, "hooks", "pre-receive"), []byte(hook), 0o755)

	fmt.Println("== Primer arranque: miembro del equipo")
	r0 := do(t, "comprobarRepo", map[string]interface{}{"url": "https://github.com/org/ALIMOCHE"}).(map[string]interface{})
	fmt.Println("  comprobarRepo sin token:", r0)
	fmt.Println("  enlace token:", do(t, "enlaceToken", map[string]interface{}{"url": "https://github.com/org/ALIMOCHE"}))
	if _, err := handle("tokenGuardar", map[string]interface{}{"token": "malo", "url": "https://github.com/org/ALIMOCHE"}); err == nil {
		t.Fatal("token malo aceptado")
	} else {
		fmt.Println("  token malo ->", err)
	}
	fmt.Println("  token bueno ->", do(t, "tokenGuardar", map[string]interface{}{"token": "tok-miembro", "url": "https://github.com/org/ALIMOCHE"}))
	if leerToken("org") != "tok-miembro" {
		t.Fatal("token no guardado")
	}
	do(t, "clonar", map[string]interface{}{"url": "https://github.com/org/ALIMOCHE", "padre": filepath.Join(tmp, "Docs"), "nombre": ""})
	repo := cfg.Repo
	n, _ := gitQuiet(repo, "config", "--local", "user.email")
	fmt.Println("  identidad local:", n)
	p := do(t, "cuenta", nil).(*Permisos)
	fmt.Printf("  permisos miembro: directo=%s integrar=%v rol=%q\n", p.Directo, p.IntegrarSinRevision, p.Rol)
	if p.Directo != "no" || p.IntegrarSinRevision {
		t.Fatal("permisos miembro mal")
	}

	// miembro edita en main, guarda (se crea rama), y envía propuesta
	os.WriteFile(filepath.Join(repo, "ALM-03.typ"), []byte("doc\n"), 0o644)
	if _, err := handle("guardar", map[string]interface{}{"titulo": "abc"}); err == nil {
		t.Fatal("debió exigir comentario")
	}
	fmt.Println(" ", do(t, "guardar", map[string]interface{}{"titulo": "ALM-03 creado", "descripcion": "borrador", "rama": "miembro/alm-03-creado"}))
	e := do(t, "estado", nil).(map[string]interface{})
	fmt.Println("  rama tras guardar:", e["rama"])
	pr := do(t, "crearPR", map[string]interface{}{"titulo": "ALM-03 creado", "cuerpo": "- ALM-03 creado"}).(map[string]interface{})
	fmt.Println("  crearPR:", pr["mensaje"])
	if _, err := handle("integrar", map[string]interface{}{"numero": float64(1)}); err == nil {
		t.Fatal("miembro no debería integrar")
	} else {
		fmt.Println("  miembro intenta integrar ->", err)
	}
	// miembro en main con commit: subir debe pedir rama sin intentar push
	do(t, "cambiarRama", map[string]interface{}{"nombre": "main"})
	os.WriteFile(filepath.Join(repo, "notas.txt"), []byte("x\n"), 0o644)
	do(t, "guardar", map[string]interface{}{"titulo": "Notas sueltas"})
	s := do(t, "subir", nil).(map[string]interface{})
	fmt.Println("  subir en main (miembro):", s)
	if s["necesitaRama"] != true {
		t.Fatal("debía pedir rama")
	}
	fmt.Println(" ", do(t, "moverARama", map[string]interface{}{"nombre": "miembro/notas"}))

	fmt.Println("== Cambio de cuenta: administrador con bypass")
	do(t, "tokenGuardar", map[string]interface{}{"token": "tok-admin", "url": "https://github.com/org/ALIMOCHE"})
	n, _ = gitQuiet(repo, "config", "--local", "user.email")
	fmt.Println("  identidad local:", n)
	p = do(t, "cuenta", nil).(*Permisos)
	fmt.Printf("  permisos admin: directo=%s integrar=%v rol=%q\n", p.Directo, p.IntegrarSinRevision, p.Rol)
	if p.Directo != "si" || !p.IntegrarSinRevision {
		t.Fatal("permisos admin mal")
	}
	prs := do(t, "prs", nil).([]map[string]interface{})
	fmt.Println("  propuestas abiertas:", len(prs))
	fmt.Println(" ", do(t, "integrar", map[string]interface{}{"numero": float64(1)}))
	do(t, "cambiarRama", map[string]interface{}{"nombre": "main"})
	do(t, "traer", nil)
	os.Setenv("PERMITIR", "1") // el bypass real lo hace GitHub; aquí lo simula el hook
	os.WriteFile(filepath.Join(repo, "ALM-00.typ"), []byte("indice\n"), 0o644)
	do(t, "guardar", map[string]interface{}{"titulo": "ALM-00 índice actualizado"})
	s = do(t, "subir", nil).(map[string]interface{})
	fmt.Println("  subir directo (admin):", s)
	os.Unsetenv("PERMITIR")
	for _, c := range historial(repo) {
		fmt.Printf("  · %s | %s | local=%v\n", c.Autor, c.Titulo, c.Local)
	}
	// administrador que prefiere propuesta: guarda en rama nueva y la envía
	os.WriteFile(filepath.Join(repo, "ALM-01.typ"), []byte("rev 0.4\n"), 0o644)
	do(t, "guardar", map[string]interface{}{"titulo": "ALM-01 Rev 0.4 para revisar", "rama": "augusto/alm-01-rev-0-4"})
	os.WriteFile(filepath.Join(repo, "ALM-01.typ"), []byte("rev 0.4b\n"), 0o644)
	do(t, "guardar", map[string]interface{}{"titulo": "ALM-01 Rev 0.4 retoque"})
	pr2 := do(t, "crearPR", map[string]interface{}{"titulo": "ALM-01 Rev 0.4", "cuerpo": "- dos versiones"}).(map[string]interface{})
	fmt.Println("  admin propuesta:", pr2["mensaje"], "| rama:", ramaActual(repo))
	// dos versiones en main y subir: se suben las dos
	do(t, "cambiarRama", map[string]interface{}{"nombre": "main"})
	os.Setenv("PERMITIR", "1")
	for i := 1; i <= 2; i++ {
		os.WriteFile(filepath.Join(repo, "v.txt"), []byte(fmt.Sprint(i)), 0o644)
		do(t, "guardar", map[string]interface{}{"titulo": fmt.Sprintf("Versión número %d", i)})
	}
	fmt.Println("  subir 2:", do(t, "subir", nil))
	os.Unsetenv("PERMITIR")
	do(t, "tokenBorrar", nil)
	if leerToken("org") != "" || tokenActual != "" {
		t.Fatal("token no borrado")
	}
	fmt.Println("== OK")
}
