package main

import (
	"bytes"
	"encoding/base64"
	"errors"
	"fmt"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
)

var gitExe string

// findGit busca git.exe: PATH, instalaciones típicas de Git for Windows
// y el MinGit que descarga el gestor completo ALIMOCHE.exe.
func findGit() string {
	if p, err := exec.LookPath("git"); err == nil {
		return p
	}
	var cands []string
	for _, env := range []string{"ProgramW6432", "ProgramFiles", "ProgramFiles(x86)"} {
		if v := os.Getenv(env); v != "" {
			cands = append(cands, filepath.Join(v, "Git", "cmd", "git.exe"))
		}
	}
	if la := os.Getenv("LOCALAPPDATA"); la != "" {
		cands = append(cands, filepath.Join(la, "Programs", "Git", "cmd", "git.exe"))
		base := filepath.Join(la, "ALIMOCHE", "herramientas")
		for _, pat := range []string{
			filepath.Join(base, "*", "cmd", "git.exe"),
			filepath.Join(base, "*", "*", "cmd", "git.exe"),
		} {
			m, _ := filepath.Glob(pat)
			cands = append(cands, m...)
		}
	}
	for _, c := range cands {
		if st, err := os.Stat(c); err == nil && !st.IsDir() {
			return c
		}
	}
	return ""
}

// git ejecuta un comando de git en dir y registra comando y salida.
func git(dir string, args ...string) (string, error) {
	if gitExe == "" {
		return "", errors.New("no se encuentra Git en este ordenador")
	}
	full := append([]string{"-c", "core.quotepath=false", "-c", "color.ui=false"}, args...)
	cmd := exec.Command(gitExe, full...)
	cmd.Dir = dir
	cmd.Env = gitEnv()
	hide(cmd)
	var out, errb bytes.Buffer
	cmd.Stdout = &out
	cmd.Stderr = &errb
	err := cmd.Run()
	so := strings.TrimRight(out.String(), "\r\n")
	se := strings.TrimSpace(errb.String())
	logCmd(args, so, se, err)
	if err != nil {
		msg := se
		if msg == "" {
			msg = so
		}
		if msg == "" {
			msg = err.Error()
		}
		return so, errors.New(msg)
	}
	return so, nil
}

// gitEnv prepara el entorno de git. Si hay token, se lo entrega a git solo
// para github.com (cabecera de autorización por variables de entorno, que no
// aparecen en la línea de comandos) y se desactiva cualquier otro ayudante de
// credenciales para que no salgan ventanas de inicio de sesión.
func gitEnv() []string {
	env := append(os.Environ(), "GIT_TERMINAL_PROMPT=0", "GCM_INTERACTIVE=never", "LC_ALL=C", "LANG=C")
	if tokenActual != "" {
		auth := base64.StdEncoding.EncodeToString([]byte("x-access-token:" + tokenActual))
		env = append(env,
			"GIT_CONFIG_COUNT=2",
			"GIT_CONFIG_KEY_0=credential.helper", "GIT_CONFIG_VALUE_0=",
			"GIT_CONFIG_KEY_1=http.https://github.com/.extraheader",
			"GIT_CONFIG_VALUE_1=AUTHORIZATION: basic "+auth,
		)
	}
	return env
}

// gitQuiet: igual pero sin registrar (consultas de estado).
func gitQuiet(dir string, args ...string) (string, error) {
	full := append([]string{"-c", "core.quotepath=false"}, args...)
	cmd := exec.Command(gitExe, full...)
	cmd.Dir = dir
	cmd.Env = gitEnv()
	hide(cmd)
	var out, errb bytes.Buffer
	cmd.Stdout = &out
	cmd.Stderr = &errb
	err := cmd.Run()
	if err != nil {
		return strings.TrimSpace(out.String()), errors.New(strings.TrimSpace(errb.String()))
	}
	return strings.TrimRight(out.String(), "\r\n"), nil
}

func logCmd(args []string, so, se string, err error) {
	var b strings.Builder
	b.WriteString("$ git " + strings.Join(args, " ") + "\n")
	if so != "" {
		b.WriteString(trunc(so) + "\n")
	}
	if se != "" {
		b.WriteString(trunc(se) + "\n")
	}
	if err != nil {
		b.WriteString("(terminó con error)\n")
	}
	emitLog(b.String())
}

func trunc(s string) string {
	if len(s) > 4000 {
		return s[:4000] + "\n…"
	}
	return s
}

// ---------- utilidades de estado ----------

type cambio struct {
	Estado string `json:"estado"`
	Ruta   string `json:"ruta"`
}

func listarCambios(dir string) []cambio {
	out, err := gitQuiet(dir, "status", "--porcelain=v1", "-z", "-uall")
	res := []cambio{}
	if err != nil {
		return res
	}
	parts := strings.Split(out, "\x00")
	for i := 0; i < len(parts); i++ {
		p := parts[i]
		if len(p) < 4 {
			continue
		}
		xy := p[:2]
		ruta := p[3:]
		if xy[0] == 'R' || xy[0] == 'C' {
			i++
		}
		var est string
		switch {
		case strings.Contains(xy, "U") || xy == "AA" || xy == "DD":
			est = "Conflicto"
		case xy == "??":
			est = "Nuevo"
		case strings.Contains(xy, "D"):
			est = "Borrado"
		case strings.Contains(xy, "R"):
			est = "Renombrado"
		case strings.Contains(xy, "A"):
			est = "Nuevo"
		default:
			est = "Modificado"
		}
		res = append(res, cambio{est, ruta})
	}
	return res
}

func ramaActual(dir string) string {
	out, err := gitQuiet(dir, "branch", "--show-current")
	if err != nil || out == "" {
		return "(sin rama)"
	}
	return out
}

func ramaPrincipal(dir string) string {
	if out, err := gitQuiet(dir, "symbolic-ref", "--short", "refs/remotes/origin/HEAD"); err == nil && out != "" {
		return strings.TrimPrefix(out, "origin/")
	}
	for _, c := range []string{"main", "master"} {
		if _, err := gitQuiet(dir, "rev-parse", "-q", "--verify", "refs/remotes/origin/"+c); err == nil {
			return c
		}
	}
	return "main"
}

func listarRamas(dir string) []string {
	out, _ := gitQuiet(dir, "for-each-ref", "--format=%(refname:short)", "refs/heads", "refs/remotes/origin")
	seen := map[string]bool{}
	res := []string{}
	for _, l := range strings.Split(out, "\n") {
		l = strings.TrimSpace(l)
		if l == "" || l == "origin" || l == "origin/HEAD" {
			continue
		}
		l = strings.TrimPrefix(l, "origin/")
		if !seen[l] {
			seen[l] = true
			res = append(res, l)
		}
	}
	return res
}

func contar(dir string, args ...string) int {
	out, err := gitQuiet(dir, args...)
	if err != nil {
		return 0
	}
	n, _ := strconv.Atoi(strings.TrimSpace(out))
	return n
}

func remotoURL(dir string) string {
	out, _ := gitQuiet(dir, "config", "--get", "remote.origin.url")
	return out
}

var reGH = regexp.MustCompile(`github\.com[:/]+([^/]+)/([^/]+?)(?:\.git)?/?$`)

// webRepo convierte la URL del remoto en la dirección web de GitHub.
func webRepo(remote string) string {
	m := reGH.FindStringSubmatch(strings.TrimSpace(remote))
	if m == nil {
		return ""
	}
	return "https://github.com/" + m[1] + "/" + m[2]
}

func nombreDesdeURL(u string) string {
	u = strings.TrimRight(strings.TrimSpace(u), "/")
	u = strings.TrimSuffix(u, ".git")
	i := strings.LastIndexAny(u, "/:")
	if i >= 0 {
		u = u[i+1:]
	}
	if u == "" {
		return "ALIMOCHE"
	}
	return u
}

func prURL(web, base, rama, titulo, cuerpo string) string {
	if web == "" {
		return ""
	}
	q := url.Values{}
	q.Set("expand", "1")
	if titulo != "" {
		q.Set("title", titulo)
	}
	if cuerpo != "" {
		q.Set("body", cuerpo)
	}
	return fmt.Sprintf("%s/compare/%s...%s?%s", web, base, rama, q.Encode())
}

func validarRama(dir, nombre string) (string, error) {
	n := strings.TrimSpace(nombre)
	n = strings.ReplaceAll(n, " ", "-")
	if n == "" {
		return "", errors.New("escribe un nombre para la rama")
	}
	if _, err := gitQuiet(dir, "check-ref-format", "--branch", n); err != nil {
		return "", fmt.Errorf("«%s» no vale como nombre de rama (evita espacios, tildes raras, «..», «~», «^», «:»)", n)
	}
	return n, nil
}

// ---------- traducción de errores frecuentes ----------

func esRechazoPermisos(msg string) bool {
	m := strings.ToLower(msg)
	for _, k := range []string{"protected branch", "gh006", "gh013", "permission to", "403", "denied", "not allowed", "rule violations", "repository rule"} {
		if strings.Contains(m, k) {
			return true
		}
	}
	return false
}

func esDesfase(msg string) bool {
	m := strings.ToLower(msg)
	return strings.Contains(m, "non-fast-forward") || strings.Contains(m, "fetch first") || strings.Contains(m, "tip of your current branch is behind")
}

func explicar(msg string) string {
	m := strings.ToLower(msg)
	switch {
	case strings.Contains(m, "conflict"):
		return "Hay conflictos: el mismo trozo de un archivo se ha cambiado aquí y en GitHub. Abre los archivos marcados como «Conflicto», deja el texto bueno (borra las marcas <<<<<<< ======= >>>>>>>) y pulsa «Guardar versión». Si prefieres no seguir, pulsa «Cancelar fusión»."
	case strings.Contains(m, "would be overwritten"):
		return "Tienes cambios sin guardar que chocan con esto. Pulsa primero «Guardar versión» y vuelve a intentarlo."
	case strings.Contains(m, "authentication failed") || strings.Contains(m, "could not read username") || strings.Contains(m, "terminal prompts disabled") || strings.Contains(m, "invalid username or token"):
		return "GitHub no ha aceptado tu token (incorrecto, caducado o sin acceso a este repositorio). Pulsa «Cuenta» → «Cambiar token» y pega uno nuevo."
	case strings.Contains(m, "write access to repository not granted") || strings.Contains(m, "permission to") && strings.Contains(m, "denied"):
		return "Tu token no tiene permiso de escritura. Al generarlo, «Contents» debe estar en «Read and write»; y tu cuenta debe tener permiso de escritura en el repositorio."
	case strings.Contains(m, "repository not found") || strings.Contains(m, "not found"):
		return "GitHub dice que ese repositorio no existe o que tu cuenta no tiene acceso. Revisa la dirección o pide que te inviten."
	case strings.Contains(m, "could not resolve host") || strings.Contains(m, "unable to access"):
		return "No hay conexión con GitHub. Revisa internet y vuelve a intentarlo."
	}
	return ""
}
