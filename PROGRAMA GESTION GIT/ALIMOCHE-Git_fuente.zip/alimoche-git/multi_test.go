package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

// Tokens simulados y a qué repos de "org" dan acceso.
var accesos = map[string][]string{
	"tok-ali":   {"ALIMOCHE"},
	"tok-cad":   {"CAD"},
	"tok-ambos": {"ALIMOCHE", "CAD"},
}

func multiGH(t *testing.T) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		tok := strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer ")
		repos, ok := accesos[tok]
		if !ok {
			w.WriteHeader(401)
			w.Write([]byte(`{"message":"Bad credentials"}`))
			return
		}
		js := func(v interface{}) { json.NewEncoder(w).Encode(v) }
		p := r.URL.Path
		if p == "/user" {
			js(map[string]interface{}{"login": "miembro", "id": 2, "name": "Miembro"})
			return
		}
		for _, rp := range repos {
			base := "/repos/org/" + rp
			switch {
			case p == base:
				js(map[string]interface{}{"full_name": "org/" + rp, "default_branch": "main", "permissions": map[string]bool{"push": true, "pull": true}})
				return
			case p == base+"/rules/branches/main":
				js([]interface{}{})
				return
			case p == base+"/branches/main":
				js(map[string]interface{}{"protected": false})
				return
			}
		}
		w.WriteHeader(404)
		w.Write([]byte(`{"message":"Not Found"}`))
	})
}

func nuevoRemoto(t *testing.T, tmp, nombre string) {
	bare := filepath.Join(tmp, nombre+".git")
	sh(t, tmp, "git", "init", "-q", "--bare", "-b", "main", bare)
	sh(t, tmp, "git", "config", "--global", "url."+bare+".insteadOf", "https://github.com/org/"+nombre+".git")
	seed := filepath.Join(tmp, "seed-"+nombre)
	sh(t, tmp, "git", "clone", "-q", bare, seed)
	os.WriteFile(filepath.Join(seed, "README.md"), []byte(nombre+"\n"), 0o644)
	sh(t, seed, "git", "-c", "user.name=a", "-c", "user.email=a@a", "add", ".")
	sh(t, seed, "git", "-c", "user.name=a", "-c", "user.email=a@a", "commit", "-qm", "inicio")
	sh(t, seed, "git", "push", "-q", "origin", "main")
}

func TestVariosRepos(t *testing.T) {
	tmp := t.TempDir()
	os.Setenv("HOME", tmp)
	os.Setenv("APPDATA", filepath.Join(tmp, "appdata"))
	os.Setenv("GIT_CONFIG_NOSYSTEM", "1")
	cfg = config{}
	tokenActual, claveActual, permCache = "", "", nil
	logHook = func(s string) {
		if !strings.HasPrefix(s, "$ git") {
			fmt.Print("    │ " + strings.TrimRight(s, "\n") + "\n")
		}
	}
	srv := httptest.NewServer(multiGH(t))
	defer srv.Close()
	apiBase = srv.URL
	loadCfg()
	gitExe = findGit()
	nuevoRemoto(t, tmp, "ALIMOCHE")
	nuevoRemoto(t, tmp, "CAD")
	docs := filepath.Join(tmp, "Docs")

	// token antiguo (v1.2) sin organización → se migra a "org"
	cfg.URL = "https://github.com/org/ALIMOCHE.git"
	guardarToken("", "", "tok-ali")
	do(t, "inicio", nil)
	if leerToken("org") != "tok-ali" || leerToken("") != "" {
		t.Fatal("no migró el token antiguo")
	}
	fmt.Println("  migración del token antiguo → clave «org» ✓")

	do(t, "clonar", map[string]interface{}{"url": "https://github.com/org/ALIMOCHE", "padre": docs})
	ali := cfg.Repo
	fmt.Println("  ALIMOCHE con token:", claveActual)

	// Añadir CAD: el token de org no le da acceso
	c := do(t, "comprobarRepo", map[string]interface{}{"url": "https://github.com/org/CAD"}).(map[string]interface{})
	fmt.Printf("  comprobar CAD: acceso=%v sinAcceso=%v clave=%v\n", c["acceso"], c["sinAcceso"], c["clave"])
	if c["sinAcceso"] != true {
		t.Fatal("debía avisar de falta de acceso")
	}
	// token malo para CAD
	if _, err := handle("tokenGuardar", map[string]interface{}{"token": "tok-ali", "url": "https://github.com/org/CAD"}); err == nil {
		t.Fatal("token sin acceso a CAD aceptado")
	} else {
		fmt.Println("  token sin acceso a CAD →", err.Error()[:60], "…")
	}
	// token que solo sirve para CAD → se guarda solo para org/CAD
	g := do(t, "tokenGuardar", map[string]interface{}{"token": "tok-cad", "url": "https://github.com/org/CAD"}).(map[string]interface{})
	fmt.Println("  token CAD →", g["clave"], "|", g["explicacion"])
	if g["clave"] != "org/CAD" {
		t.Fatal("debía guardarse solo para org/CAD")
	}
	do(t, "clonar", map[string]interface{}{"url": "https://github.com/org/CAD", "padre": docs})
	cad := cfg.Repo
	fmt.Println("  CAD activo con token:", claveActual)
	if claveActual != "org/CAD" {
		t.Fatal("CAD no usa su token")
	}
	do(t, "activar", map[string]interface{}{"ruta": ali})
	if claveActual != "org" {
		t.Fatal("ALIMOCHE no usa el token de org")
	}
	p := do(t, "cuenta", nil)
	fmt.Printf("  cuenta en ALIMOCHE: %T ok\n", p)

	// token que vale para ambos → pasa a ser el de toda la organización
	g = do(t, "tokenGuardar", map[string]interface{}{"token": "tok-ambos", "url": "https://github.com/org/CAD"}).(map[string]interface{})
	fmt.Println("  token ambos →", g["clave"], "| org/CAD sigue:", leerToken("org/CAD") != "")
	if g["clave"] != "org" || leerToken("org/CAD") != "" {
		t.Fatal("debía sustituir al de org y borrar el específico")
	}
	tl := do(t, "tokens", nil).([]map[string]interface{})
	for _, x := range tl {
		fmt.Printf("  token %v (@%v) usado por %v\n", x["clave"], x["login"], x["usan"])
	}

	// cuenta con token revocado
	guardarToken("org", "miembro", "tok-revocado")
	usarTokenDe(cfg.Repo)
	cu := do(t, "cuenta", nil).(map[string]interface{})
	fmt.Printf("  token revocado → fallo=%v caducado=%v\n", cu["fallo"], cu["caducado"])
	if cu["caducado"] != true {
		t.Fatal("debía detectar token caducado")
	}
	guardarToken("org", "miembro", "tok-ambos")

	// mover la carpeta de CAD (no activa) y quitarla
	do(t, "moverCarpeta", map[string]interface{}{"ruta": cad, "padre": filepath.Join(tmp, "Otra")})
	l := do(t, "misRepos", nil).([]map[string]interface{})
	for _, x := range l {
		fmt.Printf("  repo %v en %v activo=%v token=%v\n", x["nombre"], x["ruta"], x["activo"], x["token"])
	}
	do(t, "quitar", map[string]interface{}{"ruta": ali})
	fmt.Println("  quitado ALIMOCHE → activo ahora:", filepath.Base(cfg.Repo), "| carpeta sigue:", func() bool { _, e := os.Stat(ali); return e == nil }())
	fmt.Println("== OK varios repos")
}
