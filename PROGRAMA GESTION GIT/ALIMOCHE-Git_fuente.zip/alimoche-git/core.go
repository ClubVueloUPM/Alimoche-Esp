package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
)

const version = "1.3.0"

var logHook func(string)

var permCache *Permisos

func emitLog(s string) {
	if logHook != nil {
		logHook(s)
	}
}

var (
	opMu   sync.Mutex
	cfg    config
	cfgDir string
)

type config struct {
	Repo   string      `json:"repo"`   // carpeta activa
	URL    string      `json:"url"`    // repo elegido en el asistente
	Repos  []string    `json:"repos"`  // todas las carpetas conocidas
	Tokens []tokenInfo `json:"tokens"` // tokens guardados (solo clave y cuenta; el secreto está en Windows)
}

// Un token por organización ("org"); si hace falta, uno específico para un
// repositorio ("org/repo"), que tiene prioridad.
type tokenInfo struct {
	Clave string `json:"clave"`
	Login string `json:"login"`
}

var claveActual string

func buscarToken(remote string) (string, string) {
	o, r := ownerRepo(remote)
	if o == "" {
		return "", ""
	}
	for _, k := range []string{o + "/" + r, o} {
		if t := strings.TrimSpace(leerToken(k)); t != "" {
			return t, k
		}
	}
	return "", ""
}

func usarTokenDe(carpeta string) {
	tokenActual, claveActual = "", ""
	if carpeta != "" {
		tokenActual, claveActual = buscarToken(remotoURL(carpeta))
	}
}

// conToken ejecuta f usando temporalmente otro token para la API.
func conToken(t string, f func() error) error {
	ant := tokenActual
	tokenActual = t
	defer func() { tokenActual = ant }()
	return f()
}

func registrarToken(clave, login string) {
	for i, x := range cfg.Tokens {
		if x.Clave == clave {
			if login != "" {
				cfg.Tokens[i].Login = login
			}
			return
		}
	}
	cfg.Tokens = append(cfg.Tokens, tokenInfo{clave, login})
}

func olvidarToken(clave string) {
	borrarToken(clave)
	l := cfg.Tokens[:0]
	for _, x := range cfg.Tokens {
		if x.Clave != clave {
			l = append(l, x)
		}
	}
	cfg.Tokens = l
}

// migrarToken: las versiones 1.1–1.2 guardaban un único token sin organización.
func migrarToken() {
	t := strings.TrimSpace(leerToken(""))
	if t == "" {
		return
	}
	o := ""
	if cfg.Repo != "" {
		o, _ = ownerRepo(remotoURL(cfg.Repo))
	}
	if o == "" {
		o, _ = ownerRepo(cfg.URL)
	}
	if o == "" {
		return
	}
	if leerToken(o) == "" {
		if guardarToken(o, "", t) != nil {
			return
		}
		registrarToken(o, "")
	}
	borrarToken("")
	saveCfg()
}

func mismaRuta(a, b string) bool {
	return strings.EqualFold(filepath.Clean(a), filepath.Clean(b))
}

func quitarDeLista(ruta string) {
	l := cfg.Repos[:0]
	for _, r := range cfg.Repos {
		if !mismaRuta(r, ruta) {
			l = append(l, r)
		}
	}
	cfg.Repos = l
}

// aplicarIdentidad firma las versiones de esta carpeta con la cuenta del token:
// nombre de GitHub y su correo «noreply», que GitHub enlaza a la cuenta.
func aplicarIdentidad(d string) error {
	u, err := usuario()
	if err != nil {
		return err
	}
	if _, err := gitQuiet(d, "config", "--local", "user.name", u.nombreAutor()); err != nil {
		return err
	}
	_, err = gitQuiet(d, "config", "--local", "user.email", u.correoAutor())
	return err
}

func repoGH(d string) (string, string, error) {
	o, r := ownerRepo(remotoURL(d))
	if o == "" {
		return "", "", errors.New("este repositorio no está en GitHub")
	}
	return o, r, nil
}

func numero(a map[string]interface{}, k string) int {
	if v, ok := a[k].(float64); ok {
		return int(v)
	}
	return 0
}

func loadCfg() {
	base := os.Getenv("APPDATA")
	if base == "" {
		base, _ = os.UserConfigDir()
	}
	cfgDir = filepath.Join(base, "AlimocheGit")
	b, err := os.ReadFile(filepath.Join(cfgDir, "config.json"))
	if err == nil {
		_ = json.Unmarshal(b, &cfg)
	}
}

func saveCfg() {
	if cfg.Repo != "" {
		esta := false
		for _, r := range cfg.Repos {
			if mismaRuta(r, cfg.Repo) {
				esta = true
			}
		}
		if !esta {
			cfg.Repos = append(cfg.Repos, cfg.Repo)
		}
	}
	_ = os.MkdirAll(cfgDir, 0o755)
	b, _ := json.MarshalIndent(cfg, "", "  ")
	_ = os.WriteFile(filepath.Join(cfgDir, "config.json"), b, 0o644)
}

func str(a map[string]interface{}, k string) string {
	if v, ok := a[k]; ok && v != nil {
		if s, ok := v.(string); ok {
			return strings.TrimSpace(s)
		}
	}
	return ""
}

func repoOK() error {
	if cfg.Repo == "" {
		return errors.New("todavía no hay ninguna carpeta del repositorio elegida")
	}
	if _, err := os.Stat(filepath.Join(cfg.Repo, ".git")); err != nil {
		return fmt.Errorf("la carpeta %s ya no es un repositorio (¿se movió o se borró?). Pulsa «Repositorios» para elegir su nueva ubicación o quitarla de la lista", cfg.Repo)
	}
	return nil
}

func handle(op string, a map[string]interface{}) (interface{}, error) {
	switch op {

	case "inicio":
		if gitExe == "" {
			gitExe = findGit()
		}
		docs := filepath.Join(os.Getenv("USERPROFILE"), "Documents")
		listo := gitExe != "" && cfg.Repo != "" && repoOK() == nil
		urlRepo := cfg.URL
		if gitExe != "" {
			migrarToken()
		}
		if listo {
			urlRepo = remotoURL(cfg.Repo)
			usarTokenDe(cfg.Repo)
		}
		return map[string]interface{}{
			"git": gitExe != "", "gitPath": gitExe, "repo": cfg.Repo, "listo": listo,
			"docs": docs, "token": tokenActual != "", "url": urlRepo, "nRepos": len(cfg.Repos),
		}, nil

	case "abrirWeb":
		abrirURL(str(a, "url"))
		return nil, nil

	case "abrirRuta":
		ruta := str(a, "ruta")
		if _, err := os.Stat(ruta); err != nil {
			return nil, fmt.Errorf("no existe la carpeta %s", ruta)
		}
		_ = exec.Command("explorer", ruta).Start()
		return nil, nil

	case "elegirCarpeta":
		return elegirCarpeta(str(a, "inicial"))

	// ---------- cuenta / token ----------

	case "enlaceToken":
		o, _ := ownerRepo(httpsGitHub(str(a, "url")))
		return enlaceToken(o, a["admin"] == true), nil

	case "tokenGuardar":
		t := strings.TrimSpace(str(a, "token"))
		if t == "" {
			return nil, errors.New("pega el token que acabas de generar en GitHub")
		}
		if strings.ContainsAny(t, " \t\r\n") {
			return nil, errors.New("el token no puede tener espacios: cópialo otra vez con el botón de copiar de GitHub")
		}
		ur := httpsGitHub(str(a, "url"))
		o, r := ownerRepo(ur)
		if o == "" {
			return nil, errors.New("falta saber para qué repositorio es el token (https://github.com/organizacion/repositorio)")
		}
		var u *ghUser
		err := conToken(t, func() error {
			var e error
			if u, e = usuario(); e != nil {
				return e
			}
			_, e = repoInfo(o, r)
			return e
		})
		if err != nil {
			return nil, err
		}
		// ¿para toda la organización o solo para este repositorio?
		clave, expl := o, "Guardado para los repositorios de «"+o+"»."
		if viejo := strings.TrimSpace(leerToken(o)); viejo != "" && viejo != t {
			for _, carpeta := range cfg.Repos {
				ro, rr := ownerRepo(remotoURL(carpeta))
				if ro != o || rr == r {
					continue
				}
				if _, k := buscarToken(remotoURL(carpeta)); k != o {
					continue // ese repo ya usa su propio token
				}
				if conToken(t, func() error { _, e := repoInfo(ro, rr); return e }) != nil {
					clave = o + "/" + r
					expl = "Guardado solo para «" + o + "/" + r + "»: tu token anterior de «" + o + "» se sigue usando para «" + rr + "» y los demás, porque el nuevo no les da acceso."
					break
				}
			}
		}
		if err := guardarToken(clave, u.Login, t); err != nil {
			return nil, err
		}
		registrarToken(clave, u.Login)
		if clave == o && leerToken(o+"/"+r) != "" {
			olvidarToken(o + "/" + r)
		}
		saveCfg()
		permCache = nil
		if cfg.Repo != "" && repoOK() == nil {
			usarTokenDe(cfg.Repo)
			_ = aplicarIdentidad(cfg.Repo)
		}
		emitLog("Token comprobado: @" + u.Login + " con acceso a " + o + "/" + r + ". " + expl + "\n")
		return map[string]interface{}{"login": u.Login, "nombre": u.nombreAutor(), "clave": clave, "explicacion": expl}, nil

	case "tokenBorrar":
		clave := str(a, "clave")
		if clave == "" {
			clave = claveActual
		}
		if clave == "" {
			return nil, errors.New("no hay ningún token que borrar")
		}
		olvidarToken(clave)
		saveCfg()
		permCache = nil
		usarTokenDe(cfg.Repo)
		return nil, nil

	case "tokens":
		out := []map[string]interface{}{}
		for _, x := range cfg.Tokens {
			usan := []string{}
			for _, carpeta := range cfg.Repos {
				if _, k := buscarToken(remotoURL(carpeta)); k == x.Clave {
					_, rr := ownerRepo(remotoURL(carpeta))
					usan = append(usan, rr)
				}
			}
			out = append(out, map[string]interface{}{"clave": x.Clave, "login": x.Login, "usan": usan, "existe": leerToken(x.Clave) != ""})
		}
		return out, nil

	case "comprobarRepo":
		ur := httpsGitHub(str(a, "url"))
		o, r := ownerRepo(ur)
		if o == "" {
			return nil, errors.New("pega la dirección del repositorio de GitHub (https://github.com/organizacion/repositorio)")
		}
		cfg.URL = ur
		saveCfg()
		res := map[string]interface{}{"url": ur, "owner": o, "repo": r}
		for _, carpeta := range cfg.Repos {
			if strings.EqualFold(httpsGitHub(remotoURL(carpeta)), ur) {
				res["yaEsta"] = carpeta
			}
		}
		t, k := buscarToken(ur)
		if t == "" {
			res["acceso"], res["sinToken"] = false, true
			return res, nil
		}
		res["clave"] = k
		var u *ghUser
		err := conToken(t, func() error {
			var e error
			if u, e = usuario(); e != nil {
				return e
			}
			_, e = repoInfo(o, r)
			return e
		})
		if u != nil {
			res["login"] = u.Login
			registrarToken(k, u.Login)
			saveCfg()
		}
		if err != nil {
			res["acceso"] = false
			if ae, ok := err.(*apiError); ok && ae.Status == 401 {
				res["caducado"] = true
			} else {
				res["sinAcceso"] = true
			}
			res["motivo"] = err.Error()
			return res, nil
		}
		res["acceso"] = true
		return res, nil

	case "repos":
		return listarRepos()

	case "clonar":
		u, padre, nombre := httpsGitHub(str(a, "url")), str(a, "padre"), str(a, "nombre")
		if u == "" {
			return nil, errors.New("pega la dirección del repositorio (la de GitHub, botón verde «Code»)")
		}
		if padre == "" {
			return nil, errors.New("elige dónde guardar la carpeta")
		}
		if nombre == "" {
			nombre = nombreDesdeURL(u)
		}
		dest := filepath.Join(padre, nombre)
		if ents, err := os.ReadDir(dest); err == nil && len(ents) > 0 {
			if _, err := os.Stat(filepath.Join(dest, ".git")); err == nil {
				cfg.Repo = dest
				saveCfg()
				usarTokenDe(dest)
				emitLog("La carpeta ya contenía el repositorio; se usa tal cual.\n")
				return dest, nil
			}
			return nil, fmt.Errorf("la carpeta %s ya existe y tiene otras cosas. Elige otro nombre u otra ubicación", dest)
		}
		if err := os.MkdirAll(padre, 0o755); err != nil {
			return nil, err
		}
		emitLog("Descargando el repositorio…\n")
		ant, antK := tokenActual, claveActual
		tokenActual, claveActual = buscarToken(u)
		if _, err := git(padre, "clone", u, dest); err != nil {
			tokenActual, claveActual = ant, antK
			return nil, err
		}
		cfg.Repo = dest
		saveCfg()
		usarTokenDe(dest)
		if err := aplicarIdentidad(dest); err != nil {
			emitLog("Aviso: no se pudo leer tu cuenta para firmar las versiones: " + err.Error() + "\n")
		}
		return dest, nil

	case "abrirExistente":
		p := str(a, "ruta")
		if p == "" {
			return nil, errors.New("elige la carpeta")
		}
		top, err := gitQuiet(p, "rev-parse", "--show-toplevel")
		if err != nil {
			return nil, errors.New("esa carpeta no es un repositorio de Git. Si aún no lo tienes, usa «Descargar repositorio»")
		}
		cfg.Repo = filepath.FromSlash(top)
		saveCfg()
		usarTokenDe(cfg.Repo)
		// el token solo sirve por https: si el remoto es ssh se pasa a https
		if rem := remotoURL(cfg.Repo); rem != "" && strings.HasPrefix(rem, "git@github.com") {
			_, _ = git(cfg.Repo, "remote", "set-url", "origin", httpsGitHub(rem))
		}
		usarTokenDe(cfg.Repo)
		if tokenActual != "" {
			if err := aplicarIdentidad(cfg.Repo); err != nil {
				emitLog("Aviso: no se pudo leer tu cuenta para firmar las versiones: " + err.Error() + "\n")
			}
		}
		return cfg.Repo, nil

	case "misRepos":
		out := []map[string]interface{}{}
		for _, r := range cfg.Repos {
			_, err := os.Stat(filepath.Join(r, ".git"))
			it := map[string]interface{}{"ruta": r, "existe": err == nil, "activo": mismaRuta(r, cfg.Repo), "nombre": filepath.Base(r), "url": ""}
			if err == nil {
				rem := remotoURL(r)
				it["url"] = webRepo(rem)
				if o, n := ownerRepo(rem); o != "" {
					it["nombre"] = o + "/" + n
				}
				it["rama"] = ramaActual(r)
				it["cambios"] = len(listarCambios(r))
				_, k := buscarToken(rem)
				it["token"] = k
			}
			out = append(out, it)
		}
		return out, nil

	case "activar":
		ruta := str(a, "ruta")
		if _, err := os.Stat(filepath.Join(ruta, ".git")); err != nil {
			return nil, fmt.Errorf("en %s ya no hay un repositorio (¿se movió o se borró?). Quítalo de la lista o elige su nueva carpeta", ruta)
		}
		cfg.Repo = ruta
		permCache = nil
		saveCfg()
		usarTokenDe(ruta)
		if tokenActual != "" {
			_ = aplicarIdentidad(ruta)
		}
		return map[string]interface{}{"ruta": ruta, "token": tokenActual != "", "url": remotoURL(ruta)}, nil

	case "quitar":
		ruta := str(a, "ruta")
		quitarDeLista(ruta)
		if mismaRuta(ruta, cfg.Repo) {
			cfg.Repo = ""
			permCache = nil
			for _, otra := range cfg.Repos {
				if _, err := os.Stat(filepath.Join(otra, ".git")); err == nil {
					cfg.Repo = otra
					break
				}
			}
			usarTokenDe(cfg.Repo)
		}
		saveCfg()
		return "Quitado de la lista. La carpeta no se ha borrado: sigue en " + ruta + ".", nil

	case "moverCarpeta":
		src := str(a, "ruta")
		if src == "" {
			src = cfg.Repo
		}
		if _, err := os.Stat(filepath.Join(src, ".git")); err != nil {
			return nil, fmt.Errorf("en %s no hay un repositorio que mover", src)
		}
		eraActivo := mismaRuta(src, cfg.Repo)
		padre, nombre := str(a, "padre"), str(a, "nombre")
		if padre == "" {
			return nil, errors.New("elige la nueva ubicación")
		}
		if nombre == "" {
			nombre = filepath.Base(src)
		}
		dest := filepath.Join(padre, nombre)
		if mismaRuta(src, dest) {
			return nil, errors.New("es la misma carpeta")
		}
		if rel, err := filepath.Rel(src, dest); err == nil && !strings.HasPrefix(rel, "..") {
			return nil, errors.New("no se puede mover la carpeta dentro de sí misma")
		}
		if _, err := os.Stat(dest); err == nil {
			return nil, fmt.Errorf("ya existe %s; elige otro nombre u otra ubicación", dest)
		}
		if err := os.MkdirAll(padre, 0o755); err != nil {
			return nil, err
		}
		if err := os.Rename(src, dest); err != nil {
			msg := strings.ToLower(err.Error())
			if strings.Contains(msg, "different disk") || strings.Contains(msg, "cross-device") || strings.Contains(msg, "not same device") {
				return nil, errors.New("no se puede mover a otra unidad de disco desde aquí. Mueve la carpeta con el Explorador de Windows y luego, en «Repositorios», usa «Elegir carpeta existente» con su nueva ubicación")
			}
			return nil, errors.New("no se ha podido mover la carpeta. Cierra los archivos y programas que la estén usando (editor, PDF, Explorador dentro de ella) y vuelve a intentarlo. Detalle: " + err.Error())
		}
		for i, r := range cfg.Repos {
			if mismaRuta(r, src) {
				cfg.Repos[i] = dest
			}
		}
		if eraActivo {
			cfg.Repo = dest
		}
		saveCfg()
		emitLog("Carpeta movida: " + src + " → " + dest + "\n")
		return dest, nil

	case "olvidar":
		cfg.Repo = ""
		permCache = nil
		saveCfg()
		return nil, nil
	}

	// --- A partir de aquí hace falta repositorio ---
	if err := repoOK(); err != nil {
		return nil, err
	}
	d := cfg.Repo

	switch op {

	case "fetch":
		_, err := git(d, "fetch", "--prune", "origin")
		return nil, err

	case "estado":
		return estado(d), nil

	case "cuenta":
		o, r, err := repoGH(d)
		if err != nil {
			return nil, err
		}
		if tokenActual == "" {
			permCache = nil
			return map[string]interface{}{"fallo": true, "sinToken": true, "owner": o, "repo": r, "url": httpsGitHub(remotoURL(d))}, nil
		}
		p, err := permisos(o, r)
		if err != nil {
			permCache = nil
			res := map[string]interface{}{"fallo": true, "owner": o, "repo": r, "clave": claveActual, "motivo": err.Error(), "url": httpsGitHub(remotoURL(d))}
			if ae, ok := err.(*apiError); ok && ae.Status == 401 {
				res["caducado"] = true
			} else if strings.Contains(err.Error(), "no da acceso") {
				res["sinAcceso"] = true
			} else {
				res["sinRed"] = true
			}
			return res, nil
		}
		permCache = p
		if claveActual != "" {
			registrarToken(claveActual, p.Login)
			saveCfg()
		}
		return p, nil

	case "prs":
		o, r, err := repoGH(d)
		if err != nil {
			return nil, err
		}
		l, err := listarPRs(o, r)
		if err != nil {
			return nil, err
		}
		out := []map[string]interface{}{}
		for _, x := range l {
			out = append(out, map[string]interface{}{
				"numero": x.Number, "titulo": x.Title, "autor": x.User.Login, "rama": x.Head.Ref,
				"base": x.Base.Ref, "url": x.HTMLURL, "borrador": x.Draft, "fecha": fechaCorta(x.Created),
				"cuerpo": x.Body,
			})
		}
		return out, nil

	case "integrar":
		o, r, err := repoGH(d)
		if err != nil {
			return nil, err
		}
		n := numero(a, "numero")
		if n <= 0 {
			return nil, errors.New("propuesta no válida")
		}
		msg, err := integrarPR(o, r, n)
		if err != nil {
			return nil, err
		}
		_, _ = git(d, "fetch", "--prune", "origin")
		if ramaActual(d) == ramaPrincipal(d) && len(listarCambios(d)) == 0 {
			_, _ = git(d, "pull", "--no-rebase", "--no-edit")
		}
		return msg, nil

	case "historial":
		return historial(d), nil

	case "traer":
		rama := ramaActual(d)
		if _, err := gitQuiet(d, "rev-parse", "--abbrev-ref", "@{u}"); err != nil {
			if _, err2 := gitQuiet(d, "rev-parse", "-q", "--verify", "refs/remotes/origin/"+rama); err2 == nil {
				_, _ = git(d, "branch", "--set-upstream-to=origin/"+rama)
			} else {
				_, err := git(d, "fetch", "--prune", "origin")
				if err != nil {
					return nil, err
				}
				return "La rama «" + rama + "» todavía no está en GitHub, así que no hay nada suyo que traer. Si quieres las novedades de " + ramaPrincipal(d) + ", usa «Actualizar con " + ramaPrincipal(d) + "».", nil
			}
		}
		out, err := git(d, "pull", "--no-rebase", "--no-edit", "--autostash")
		if err != nil {
			return nil, err
		}
		if strings.Contains(out, "Already up to date") {
			return "Ya estabas al día.", nil
		}
		return "Cambios traídos.", nil

	case "actualizarConMain":
		p := ramaPrincipal(d)
		if _, err := git(d, "fetch", "--prune", "origin"); err != nil {
			return nil, err
		}
		out, err := git(d, "merge", "--no-edit", "--autostash", "origin/"+p)
		if err != nil {
			return nil, err
		}
		if strings.Contains(out, "Already up to date") {
			return "Tu rama ya tenía todo lo de " + p + ".", nil
		}
		return "Novedades de " + p + " incorporadas a tu rama. Pulsa «Subir» para que también estén en GitHub.", nil

	case "nuevaRama":
		n, err := validarRama(d, str(a, "nombre"))
		if err != nil {
			return nil, err
		}
		for _, r := range listarRamas(d) {
			if r == n {
				return nil, fmt.Errorf("ya existe una rama llamada «%s»; elígela en la lista", n)
			}
		}
		_, err = git(d, "switch", "-c", n)
		return n, err

	case "cambiarRama":
		n := str(a, "nombre")
		if n == "" {
			return nil, errors.New("elige una rama")
		}
		if _, err := git(d, "switch", n); err != nil {
			return nil, err
		}
		return n, nil

	case "guardar":
		titulo, desc := str(a, "titulo"), str(a, "descripcion")
		if len([]rune(titulo)) < 5 {
			return nil, errors.New("el comentario es obligatorio: escribe un título que explique qué has cambiado (mínimo 5 letras)")
		}
		if n, _ := gitQuiet(d, "config", "--local", "user.name"); n == "" {
			if err := aplicarIdentidad(d); err != nil {
				return nil, errors.New("no se puede leer tu cuenta de GitHub para firmar la versión: " + err.Error())
			}
		}
		// Miembros sin acceso directo: si están en la principal, la versión
		// se guarda en una rama nueva para su propuesta.
		if nr := str(a, "rama"); nr != "" && len(listarCambios(d)) > 0 {
			n, err := validarRama(d, nr)
			if err != nil {
				return nil, err
			}
			if _, err := git(d, "switch", "-c", n); err != nil {
				return nil, err
			}
		}
		if _, err := git(d, "add", "-A"); err != nil {
			return nil, err
		}
		_, enFusion := gitQuiet(d, "rev-parse", "-q", "--verify", "MERGE_HEAD")
		if _, err := gitQuiet(d, "diff", "--cached", "--quiet"); err == nil && enFusion != nil {
			return nil, errors.New("no hay cambios que guardar")
		}
		args := []string{"commit", "-m", titulo}
		if desc != "" {
			args = append(args, "-m", desc)
		}
		if _, err := git(d, args...); err != nil {
			return nil, err
		}
		return "Versión guardada en tu ordenador. Pulsa «Subir» para mandarla a GitHub.", nil

	case "cancelarFusion":
		_, err := git(d, "merge", "--abort")
		return "Fusión cancelada: todo vuelve a como estaba antes de traer.", err

	case "subir":
		rama := ramaActual(d)
		p := ramaPrincipal(d)
		nVers := contar(d, "rev-list", "--count", "HEAD", "--not", "--remotes")
		if rama == p && permCache != nil && permCache.Directo == "no" {
			if contar(d, "rev-list", "--count", "HEAD", "--not", "--remotes") == 0 {
				return map[string]interface{}{"mensaje": "No hay versiones nuevas que subir."}, nil
			}
			return map[string]interface{}{"necesitaRama": true}, nil
		}
		_, err := git(d, "push", "-u", "origin", "HEAD")
		if err != nil {
			msg := err.Error()
			if esDesfase(msg) {
				return nil, errors.New("GitHub tiene novedades que tú aún no tienes. Pulsa «Traer cambios» y luego vuelve a «Subir»")
			}
			if esRechazoPermisos(msg) && rama == p {
				return map[string]interface{}{"necesitaRama": true, "detalle": msg}, nil
			}
			if esRechazoPermisos(msg) {
				return nil, errors.New("GitHub no te deja subir: tu cuenta no tiene permiso de escritura en este repositorio. Pide al administrador que te invite como colaborador")
			}
			return nil, err
		}
		que := "Todo estaba ya en GitHub."
		switch {
		case nVers == 1:
			que = "Subida 1 versión"
		case nVers > 1:
			que = fmt.Sprintf("Subidas %d versiones (cada una con su comentario)", nVers)
		}
		res := map[string]interface{}{"mensaje": que + " a " + rama + "."}
		if nVers == 0 {
			res["mensaje"] = que
		}
		if rama != p {
			res["mensaje"] = res["mensaje"].(string) + " Cuando quieras que se incorpore a " + p + ", pulsa «Enviar propuesta»."
			res["puedePR"] = true
		}
		return res, nil

	case "moverARama":
		n, err := validarRama(d, str(a, "nombre"))
		if err != nil {
			return nil, err
		}
		p := ramaPrincipal(d)
		if _, err := git(d, "switch", "-c", n); err != nil {
			return nil, err
		}
		if _, err := git(d, "branch", "-f", p, "origin/"+p); err != nil {
			return nil, err
		}
		if _, err := git(d, "push", "-u", "origin", "HEAD"); err != nil {
			return nil, err
		}
		return "Tus versiones están ahora en la rama «" + n + "» y ya están en GitHub. Ahora envía la propuesta para que alguien con permiso la revise e incorpore a " + p + ".", nil

	case "datosPR":
		p := ramaPrincipal(d)
		rama := ramaActual(d)
		if rama == p {
			return nil, errors.New("estás en " + p + ". Las propuestas se hacen desde una rama: crea una con «Nueva rama»")
		}
		titulo, _ := gitQuiet(d, "log", "-1", "--format=%s")
		lista, _ := gitQuiet(d, "log", "--reverse", "--format=- %s", "origin/"+p+"..HEAD")
		pend := contar(d, "rev-list", "--count", "HEAD", "--not", "--remotes")
		return map[string]interface{}{"titulo": titulo, "cuerpo": lista, "rama": rama, "base": p, "sinSubir": pend}, nil

	case "crearPR":
		titulo, cuerpo := str(a, "titulo"), str(a, "cuerpo")
		if len([]rune(titulo)) < 5 {
			return nil, errors.New("pon un título a la propuesta (mínimo 5 letras)")
		}
		if len([]rune(cuerpo)) < 5 {
			return nil, errors.New("escribe un comentario para el revisor: qué cambia y por qué")
		}
		o, r, err := repoGH(d)
		if err != nil {
			return nil, err
		}
		p, rama := ramaPrincipal(d), ramaActual(d)
		if rama == p {
			return nil, errors.New("estás en " + p + ": las propuestas se hacen desde una rama")
		}
		// lo que falte por subir se sube antes de proponer
		_, sinU := gitQuiet(d, "rev-parse", "--abbrev-ref", "@{u}")
		if sinU != nil || contar(d, "rev-list", "--count", "HEAD", "--not", "--remotes") > 0 {
			if _, err := git(d, "push", "-u", "origin", "HEAD"); err != nil {
				if esDesfase(err.Error()) {
					return nil, errors.New("tu rama en GitHub tiene cambios que tú no tienes. Pulsa «Traer cambios» y vuelve a enviar")
				}
				return nil, err
			}
		}
		pr, existia, err := crearPR(o, r, p, rama, titulo, cuerpo)
		if err != nil {
			return nil, err
		}
		msg := fmt.Sprintf("Propuesta #%d enviada: «%s». Quien tenga permiso la revisará e integrará en %s.", pr.Number, pr.Title, p)
		if existia {
			msg = fmt.Sprintf("Esta rama ya tenía la propuesta #%d abierta; tus versiones nuevas se han añadido a ella.", pr.Number)
		}
		return map[string]interface{}{"mensaje": msg, "url": pr.HTMLURL, "numero": pr.Number}, nil

	case "abrirCarpeta":
		c := exec.Command("explorer", d)
		_ = c.Start()
		return nil, nil

	case "verGitHub":
		web := webRepo(remotoURL(d))
		if web == "" {
			return nil, errors.New("no se reconoce la dirección de GitHub de este repositorio")
		}
		abrirURL(web)
		return nil, nil
	}
	return nil, fmt.Errorf("operación desconocida: %s", op)
}

func estado(d string) map[string]interface{} {
	rama := ramaActual(d)
	p := ramaPrincipal(d)
	tieneU := true
	detras, adelante := 0, 0
	if out, err := gitQuiet(d, "rev-list", "--left-right", "--count", "@{u}...HEAD"); err == nil {
		fmt.Sscanf(out, "%d %d", &detras, &adelante)
	} else {
		tieneU = false
		adelante = contar(d, "rev-list", "--count", "HEAD", "--not", "--remotes")
	}
	_, errM := gitQuiet(d, "rev-parse", "-q", "--verify", "MERGE_HEAD")
	detrasMain := 0
	if rama != p {
		detrasMain = contar(d, "rev-list", "--count", "HEAD..origin/"+p)
	}
	return map[string]interface{}{
		"repo": d, "nombreRepo": filepath.Base(d), "web": webRepo(remotoURL(d)),
		"rama": rama, "principal": p, "ramas": listarRamas(d),
		"cambios": listarCambios(d), "adelante": adelante, "detras": detras,
		"tieneRemoto": tieneU, "fusion": errM == nil, "detrasMain": detrasMain,
	}
}

type commitInfo struct {
	Hash   string `json:"hash"`
	Autor  string `json:"autor"`
	Fecha  string `json:"fecha"`
	Titulo string `json:"titulo"`
	Cuerpo string `json:"cuerpo"`
	Local  bool   `json:"local"`
}

func historial(d string) []commitInfo {
	res := []commitInfo{}
	locales := map[string]bool{}
	if out, err := gitQuiet(d, "rev-list", "HEAD", "--not", "--remotes"); err == nil {
		for _, h := range strings.Fields(out) {
			locales[h] = true
		}
	}
	out, err := gitQuiet(d, "log", "-n", "60", "--date=format:%d/%m/%Y %H:%M", "--format=%H%x1f%an%x1f%ad%x1f%s%x1f%b%x1e")
	if err != nil {
		return res
	}
	for _, rec := range strings.Split(out, "\x1e") {
		rec = strings.TrimLeft(rec, "\r\n")
		f := strings.Split(rec, "\x1f")
		if len(f) < 5 {
			continue
		}
		res = append(res, commitInfo{f[0][:min(10, len(f[0]))], f[1], f[2], f[3], strings.TrimSpace(f[4]), locales[f[0]]})
	}
	return res
}

func abrirURL(u string) {
	if u == "" {
		return
	}
	c := exec.Command("rundll32", "url.dll,FileProtocolHandler", u)
	hide(c)
	_ = c.Start()
}

func elegirCarpeta(inicial string) (string, error) {
	ps := `Add-Type -AssemblyName System.Windows.Forms;` +
		`[Console]::OutputEncoding=[Text.Encoding]::UTF8;` +
		`$f=New-Object System.Windows.Forms.FolderBrowserDialog;` +
		`$f.Description='Elige la carpeta';$f.ShowNewFolderButton=$true;` +
		`if($env:ALM_INI -and (Test-Path $env:ALM_INI)){$f.SelectedPath=$env:ALM_INI};` +
		`$o=New-Object System.Windows.Forms.Form -Property @{TopMost=$true};` +
		`if($f.ShowDialog($o) -eq 'OK'){[Console]::Out.Write($f.SelectedPath)}`
	c := exec.Command("powershell", "-NoProfile", "-STA", "-ExecutionPolicy", "Bypass", "-Command", ps)
	c.Env = append(os.Environ(), "ALM_INI="+inicial)
	hide(c)
	out, err := c.Output()
	if err != nil {
		return "", errors.New("no se pudo abrir el selector de carpetas; escribe la ruta a mano")
	}
	return strings.TrimSpace(string(out)), nil
}

func fechaCorta(iso string) string {
	if len(iso) >= 10 {
		return iso[8:10] + "/" + iso[5:7] + "/" + iso[0:4]
	}
	return iso
}
