//go:build windows

package main

import (
	"errors"
	"syscall"
	"unsafe"
)

// Los tokens se guardan en el Administrador de credenciales de Windows
// (Credenciales de Windows → "AlimocheGit:github.com/<organización>"),
// cifrados por Windows y solo accesibles con la sesión de este usuario.

const credPrefix = "AlimocheGit:github.com/"
const credLegacy = "AlimocheGit:github.com" // v1.1–1.2: un único token

type winCredential struct {
	Flags              uint32
	Type               uint32
	TargetName         *uint16
	Comment            *uint16
	LastWritten        [2]uint32
	CredentialBlobSize uint32
	CredentialBlob     *byte
	Persist            uint32
	AttributeCount     uint32
	Attributes         uintptr
	TargetAlias        *uint16
	UserName           *uint16
}

var (
	advapi32      = syscall.NewLazyDLL("advapi32.dll")
	procCredWrite = advapi32.NewProc("CredWriteW")
	procCredRead  = advapi32.NewProc("CredReadW")
	procCredDel   = advapi32.NewProc("CredDeleteW")
	procCredFree  = advapi32.NewProc("CredFree")
)

func credTarget(clave string) string {
	if clave == "" {
		return credLegacy
	}
	return credPrefix + clave
}

func guardarToken(clave, login, token string) error {
	t, _ := syscall.UTF16PtrFromString(credTarget(clave))
	u, _ := syscall.UTF16PtrFromString(login)
	c, _ := syscall.UTF16PtrFromString("ALIMOCHE · Git")
	blob := []byte(token)
	cred := winCredential{
		Type:               1, // CRED_TYPE_GENERIC
		TargetName:         t,
		Comment:            c,
		CredentialBlobSize: uint32(len(blob)),
		CredentialBlob:     &blob[0],
		Persist:            2, // CRED_PERSIST_LOCAL_MACHINE
		UserName:           u,
	}
	r, _, e := procCredWrite.Call(uintptr(unsafe.Pointer(&cred)), 0)
	if r == 0 {
		return errors.New("no se pudo guardar el token en el Administrador de credenciales de Windows: " + e.Error())
	}
	return nil
}

func leerToken(clave string) string {
	t, _ := syscall.UTF16PtrFromString(credTarget(clave))
	var p *winCredential
	r, _, _ := procCredRead.Call(uintptr(unsafe.Pointer(t)), 1, 0, uintptr(unsafe.Pointer(&p)))
	if r == 0 || p == nil {
		return ""
	}
	defer procCredFree.Call(uintptr(unsafe.Pointer(p)))
	if p.CredentialBlobSize == 0 || p.CredentialBlob == nil {
		return ""
	}
	return string(unsafe.Slice(p.CredentialBlob, p.CredentialBlobSize))
}

func borrarToken(clave string) {
	t, _ := syscall.UTF16PtrFromString(credTarget(clave))
	procCredDel.Call(uintptr(unsafe.Pointer(t)), 1, 0)
}
