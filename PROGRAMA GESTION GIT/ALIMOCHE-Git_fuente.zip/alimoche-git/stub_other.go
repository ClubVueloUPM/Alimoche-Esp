//go:build !windows

package main

import (
	"os"
	"os/exec"
	"path/filepath"
	"strings"
)

// Versión para pruebas fuera de Windows: los tokens van a archivos.

func hide(c *exec.Cmd) {}

func tokenFile(clave string) string {
	if clave == "" {
		clave = "_legacy"
	}
	return filepath.Join(cfgDir, "tokens", strings.ReplaceAll(clave, "/", "__")+".txt")
}

func guardarToken(clave, login, token string) error {
	_ = os.MkdirAll(filepath.Join(cfgDir, "tokens"), 0o700)
	return os.WriteFile(tokenFile(clave), []byte(token), 0o600)
}

func leerToken(clave string) string {
	b, _ := os.ReadFile(tokenFile(clave))
	return string(b)
}

func borrarToken(clave string) { _ = os.Remove(tokenFile(clave)) }
