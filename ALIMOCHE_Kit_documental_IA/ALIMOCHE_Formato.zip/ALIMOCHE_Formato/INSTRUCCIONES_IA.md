# ALIMOCHE · Instrucciones para la IA que redacta o convierte documentos

Estas instrucciones son para una IA (Claude u otra) que recibe este paquete en un chat o en un proyecto. Su trabajo: **convertir el material que le dé el responsable (normalmente un Word con lo investigado) en un documento ALIMOCHE** y devolver el original **Typst (`.typ`)** y su **PDF**.

El formato está fijado en `documentos/ALM-FMT-01/ALM-FMT-01_Rev-0.1.pdf` (norma de formato, compuesta con la propia plantilla). Léela antes de empezar: es la referencia visual y de reglas. Este archivo resume lo operativo.

---

## Texto para pegar en el chat

> Te adjunto el kit de formato de ALIMOCHE (`ALIMOCHE_Formato.zip`) y un documento con mi investigación. Descomprime el kit, lee `INSTRUCCIONES_IA.md` y la norma `ALM-FMT-01`, y convierte mi documento en un documento ALIMOCHE con la plantilla. Código: `<CÓDIGO>`. Título: `<TÍTULO>`. Tipo: `<TIPO>`. Autor: `<NOMBRE>`. Revisión `0.1`, estado Borrador, fecha `<DD/MM/AAAA>`. Devuélveme un ZIP con la carpeta `documentos/<CÓDIGO>/` completa (`.typ`, `figuras/`, `datos/` y el PDF) y el PDF también suelto.

Si el responsable no da código, título, tipo o autor, pregúntalo una vez; si no responde, usa lo que figure en el documento de entrada y márcalo en el resumen final.

---

## 1. Preparar el entorno

```bash
unzip ALIMOCHE_Formato.zip && cd ALIMOCHE_Formato
# Typst 0.15.1: si no está instalado, el script lo extrae de herramientas/ (Linux x86-64)
./herramientas/compilar.sh ALM-FMT-01      # prueba: debe escribir el PDF de la norma
```

- En Windows: `.\herramientas\compilar.ps1 ALM-FMT-01` con `typst.exe` en el PATH.
- Los avisos `unknown font family: arial` / `consolas` son normales en Linux: la plantilla cae en Liberation Sans (métrica idéntica a Arial, incluida en `plantilla/fuentes/`) y DejaVu Sans Mono. No cambies las fuentes.
- Python con `matplotlib` y `numpy` para las gráficas; `pandoc` para leer Word (`pip install --break-system-packages matplotlib numpy` si faltan).

## 2. Crear la carpeta del documento

```bash
cp -r documentos/_NUEVO documentos/<CÓDIGO>
mv documentos/<CÓDIGO>/NUEVO.typ documentos/<CÓDIGO>/<CÓDIGO>.typ
```

Rellena **solo** el bloque `#show: documento.with(...)`. Nunca copies ni modifiques `plantilla/alimoche.typ`: si algo no se puede hacer con la plantilla, dilo en el resumen en vez de cambiarla.

## 3. Extraer el contenido del Word

```bash
pandoc entrada.docx -t typst --extract-media=documentos/<CÓDIGO>/figuras/_word -o /tmp/borrador.typ
```

Ese borrador es **materia prima, no el resultado**. Pandoc deja numeración manual («= 1. Objeto»), `#blockquote`, `#align(center)[#table(... inset ...)]`, etiquetas `<objeto-y-entradas>` y estilos que contradicen la norma. Reescribe el contenido en el `.typ` siguiendo la plantilla. Las ecuaciones de Word suelen convertirse bien; revísalas.

Si la entrada es PDF, usa `pdftotext -layout` para el texto y `pdfimages -png` para las imágenes. Si es Excel, exporta las hojas necesarias a CSV en `datos/`.

## 4. Reglas de contenido (no negociables)

1. **No alteres datos, cifras, conclusiones ni identificadores.** Puedes reordenar, unificar redacción y corregir erratas evidentes. Si corriges algo de fondo, dilo en el resumen.
2. **No inventes**: ni datos, ni referencias, ni fechas, ni nombres, ni firmas, ni aprobaciones. Lo que falte o sea dudoso va en `#pendiente[...]`.
3. **Estado y revisión**: lo que diga el responsable. Por defecto Borrador, 0.1. Nunca «Aprobado» sin que el responsable lo diga expresamente. La firma (`firma: image(...)`) solo si él lo pide y aporta la imagen.
4. Los identificadores (ASM-01, REQ-01, CRIT-01, LEG-01...) se conservan **tal cual**. Sin ceros sobrantes en los nuevos. No se renumeran.
5. Idioma: español, impersonal, frases cortas, sin adornos ni negritas de relleno.

## 5. Reglas de forma (resumen de ALM-FMT-01)

| Elemento | Cómo |
|---|---|
| Metadatos | Solo en `documento.with(...)` → cajetín. Nada de portada, ni historial de revisiones, ni autor/fecha en el cuerpo. |
| Primer título | Lo pone la plantilla (solo el título). No añadas otro. |
| Títulos | `=` y `==`, numerados automáticamente. **No escribas números a mano.** `===` sin número, solo excepcionalmente. Sin subsecciones de un único párrafo. |
| Estructura típica | Objeto y alcance · Datos de entrada · Desarrollo (uno o varios apartados) · Conclusiones/salidas · Referencias · Anexos. Adáptala al contenido; no rellenes apartados vacíos. |
| Identificadores | `#item("REQ-01", "Título")[texto]`. Si son muchos y cortos, mejor una tabla con columna «ID». |
| Notas / abiertos | `#nota[...]` · `#pendiente[...]` |
| Números | **Punto decimal** en todo (texto, tablas, ecuaciones, gráficas): `1.04`. Millares con espacio fino a partir de 5 cifras (`15 690`), nunca con coma ni punto. `#num(15690)`, `#num(0.055, dec: 3)`; con unidad `#q(9.81, "m/s²", dec: 2)`. Si el Word trae coma decimal, se pasa a punto. |
| Unidades | SI, espacio entre número y unidad, «Magnitud (unidad)» en cabeceras y ejes; adimensionales «(–)». |
| Fechas | DD/MM/AAAA. |
| Tablas | `#figure(table(...), caption: [...]) <tab:nombre>`. Primera fila = cabecera (la plantilla la pone en negrita y gris). Texto a la izquierda, cifras a la derecha (`align: (left, right, ...)`), mismos decimales por columna. No pongas `stroke`, `fill` ni `inset` propios. Fuente debajo con `#fuente[...]`. |
| Tablas de Excel | CSV en `datos/` → `#tabla-csv(csv("datos/x.csv"), columnas: (...), alinear: (...))`. Si viene de Excel en español (`;` y coma decimal): `csv(..., delimiter: ";")` y `coma-a-punto: true`. |
| Figuras | `#figure(image("figuras/x.svg", width: 100%), caption: [...]) <fig:nombre>`. Pie debajo, describe lo que se ve y su origen. Citar en el texto antes de que aparezca: `@fig:nombre`, `@tab:nombre`, `@eq:nombre`. |
| Gráficas | **Rehazlas** con `plantilla/graficas/alimoche_graficas.py` siempre que haya datos o fórmula (ver §6). Solo si no hay forma de obtener los datos, conserva la imagen original e indícalo en el pie. |
| Imágenes | Fotos JPG, esquemas SVG/PNG ~300 ppp. Ancho 160 mm (completo) o 78 mm (media). Nombres de archivo sin espacios ni tildes. |
| Ecuaciones | `$ ... $ <eq:nombre>` aparte y numeradas; variables definidas justo después («donde ...»). En línea: `$q = 1/2 rho V^2$`. |
| Referencias | `#referencias(([...], [...]))` al final, antes de anexos. Citar en el texto como [1], [2]. Solo referencias que estén en el material de entrada. |
| Anexos | `#show: anexos` y luego `= Título` → «Anexo A». |
| Índice | `indice: true` si pasa de unas 6 hojas. |
| Colores | Ninguno en texto, tablas ni cajetín. En gráficas, solo con varias series y siempre combinado con trazo distinto (ver §6). |

## 6. Gráficas

Un script por gráfica en `documentos/<CÓDIGO>/figuras/`, que lee de `datos/` (o calcula) y escribe el SVG con el mismo nombre. Ejemplo completo: `documentos/ALM-FMT-01/figuras/polar_ejemplo.py`.

```python
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[3] / "plantilla" / "graficas"))
import alimoche_graficas as ag
import csv

filas = list(csv.reader(open(pathlib.Path(__file__).parents[1] / "datos" / "descenso.csv", encoding="utf-8"), delimiter=";"))
x = [float(f[0].replace(",", ".")) for f in filas[1:]]   # admite CSV con coma o punto
y = [float(f[1].replace(",", ".")) for f in filas[1:]]

fig, ax = ag.figura(160, 80)            # ancho, alto en mm
ax.plot(x, y, **ag.serie(0), label="Lillo 40 °C")
ax.axhline(1.0, **ag.LIMITE)            # línea de límite / referencia
ax.set_xlabel("Velocidad (km/h)"); ax.set_ylabel("Descenso (m/s)")
ag.leyenda(ax)                          # solo si hay más de una serie
ag.guardar(fig, __file__)               # -> descenso.svg
```

- Sin título dentro de la gráfica; el título es el pie de figura.
- Una sola curva: negro continuo (`ag.serie(0)`).
- Varias curvas: `ag.serie(0)`, `ag.serie(1)`... combinan **color + tipo de trazo** (y marcador desde la 5.ª), para que se distingan también impresas en blanco y negro. Nunca distingas series solo por color. `ag.serie(i, color=False)` da la versión en negro/gris.
- Barras: `ag.barras(i)` (grises); `ag.barras(i, color=True)` añade color y trama.
- Ejes con «Magnitud (unidad)». El punto decimal y los decimales homogéneos los pone el módulo.

## 7. Compilar y comprobar

```bash
./herramientas/compilar.sh <CÓDIGO>     # regenera gráficas y escribe <CÓDIGO>_Rev-<rev>.pdf
pdftoppm -r 70 -png documentos/<CÓDIGO>/<CÓDIGO>_Rev-<rev>.pdf /tmp/rev
```

**Mira cada página renderizada** antes de entregar y comprueba:

- [ ] Compila sin errores (los avisos de Arial/Consolas no cuentan).
- [ ] Cajetín correcto en todas las hojas; «Hoja n / N» bien.
- [ ] Ningún número de apartado escrito a mano; nada de `#blockquote`, `#align(center)[#table` ni estilos propios en tablas.
- [ ] Todas las tablas y figuras numeradas, citadas en el texto, con pie; sin referencias rotas («??»).
- [ ] Punto decimal en texto, tablas, ecuaciones y gráficas; unidades con espacio.
- [ ] Gráficas legibles impresas en blanco y negro (color siempre con trazo distinto), sin título interno, texto del tamaño del documento.
- [ ] Nada se sale del marco; sin huecos grandes por figuras mal colocadas.
- [ ] Ningún dato inventado; dudas en `#pendiente`.

## 8. Entregar

1. ZIP con `documentos/<CÓDIGO>/` completo: `<CÓDIGO>.typ`, `figuras/` (scripts `.py`, `.svg`, imágenes), `datos/` (CSV) y `<CÓDIGO>_Rev-<rev>.pdf`. Sin la carpeta `figuras/_word` si ya no se usa.
2. El PDF también suelto, para verlo directamente.
3. Un resumen breve: qué se ha convertido, qué gráficas se rehicieron y cuáles se conservaron como imagen, qué se marcó como pendiente, y cualquier cambio de redacción que afecte al fondo.

## 9. Revisar un documento ALIMOCHE ya existente

Si el responsable entrega un PDF antiguo (Word, LibreOffice, ReportLab u otra plantilla), se trata igual que un Word: se extrae el contenido y se compone de nuevo con esta plantilla, **conservando el código, la revisión que él indique y todos los identificadores**. Las diferencias de forma del original (títulos tipo «OBJ objeto», numeración manual, coma decimal, series distinguidas solo por color, cabeceras distintas) se corrigen; las de fondo, no: se señalan.
