#!/usr/bin/env bash
# Compila un documento ALIMOCHE:  ./herramientas/compilar.sh ALM-P00-A06
# - Regenera las gráficas (documentos/<CÓDIGO>/figuras/*.py) si hay Python
# - Lee la revisión del .typ y escribe documentos/<CÓDIGO>/<CÓDIGO>_Rev-<rev>.pdf
set -euo pipefail
cd "$(dirname "$0")/.."
COD="${1:?Uso: compilar.sh <CÓDIGO>}"
DIR="documentos/$COD"; SRC="$DIR/$COD.typ"
[ -f "$SRC" ] || { echo "No existe $SRC"; exit 1; }
TYPST="${TYPST:-typst}"
if ! command -v "$TYPST" >/dev/null 2>&1; then
  if [ ! -x herramientas/typst/typst ]; then
    mkdir -p herramientas/typst
    tar -xJf herramientas/typst-0.15.1-linux-x86_64.tar.xz -C herramientas/typst --strip-components=1
  fi
  TYPST=herramientas/typst/typst
fi
for py in "$DIR"/figuras/*.py; do [ -e "$py" ] && python3 "$py"; done
REV=$(grep -oP 'revision:\s*"\K[^"]+' "$SRC" | head -1)
OUT="$DIR/${COD}_Rev-${REV}.pdf"
"$TYPST" compile --root . --font-path plantilla/fuentes "$SRC" "$OUT"
echo "OK -> $OUT"
