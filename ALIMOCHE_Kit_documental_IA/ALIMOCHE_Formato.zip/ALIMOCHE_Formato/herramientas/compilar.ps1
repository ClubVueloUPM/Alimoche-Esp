# Compila un documento ALIMOCHE en Windows:  .\herramientas\compilar.ps1 ALM-P00-A06
# Requiere typst.exe en el PATH (o -Typst ruta\typst.exe). Python opcional para regenerar gráficas.
param([Parameter(Mandatory=$true)][string]$Codigo, [string]$Typst = "typst")
$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "..")
$dir = "documentos/$Codigo"; $src = "$dir/$Codigo.typ"
if (-not (Test-Path $src)) { throw "No existe $src" }
Get-ChildItem "$dir/figuras/*.py" -ErrorAction SilentlyContinue | ForEach-Object { python $_.FullName }
$rev = ([regex]::Match((Get-Content $src -Raw -Encoding UTF8), 'revision:\s*"([^"]+)"')).Groups[1].Value
$out = "$dir/${Codigo}_Rev-$rev.pdf"
& $Typst compile --root . --font-path plantilla/fuentes $src $out
Write-Host "OK -> $out"
