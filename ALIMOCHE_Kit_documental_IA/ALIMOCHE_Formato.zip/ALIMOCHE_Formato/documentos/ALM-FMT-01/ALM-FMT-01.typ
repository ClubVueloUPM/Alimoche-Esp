#import "../../plantilla/alimoche.typ": *

#show: documento.with(
  codigo: "ALM-FMT-01",
  titulo: "Norma de formato documental",
  tipo: "Norma interna",
  revision: "0.1",
  estado: "Borrador",
  creado: "28/10/2026",
  autor: "Augusto Aizpún",
  revisor: "Pendiente",
  aprobacion: "Pendiente",
  indice: true,
)

= Objeto y alcance

Esta norma fija el *aspecto* de todos los documentos de ALIMOCHE: página, cajetín, tipografía, títulos, tablas, gráficas, figuras, ecuaciones y la forma de escribir números y unidades. Su objetivo es que cualquier documento, lo redacte una persona o una IA, sea indistinguible en forma de los demás.

La norma no fija la estructura del archivo documental (árbol de documentos, códigos, dependencias ni nombres definitivos). Eso se hará en un documento posterior. Mientras tanto, los códigos siguen el uso local actual (ALM-00, ALM-P00, ALM-P00-A01...) y el código de esta misma norma es provisional.

Todo lo que aquí se muestra está compuesto con la propia plantilla: este PDF es a la vez la norma y la muestra de referencia.

= Herramientas y archivos

El original de cada documento es su archivo *Typst* (`.typ`). El PDF es un derivado que se regenera al compilar; nunca se edita el PDF ni se mantiene un Word paralelo. Se usa Typst 0.15.1.

#figure(
  table(
    columns: (44mm, 1fr),
    align: (left, left),
    [Ruta], [Contenido],
    [`plantilla/alimoche.typ`], [Plantilla común. Ningún documento la copia ni la modifica; todos la importan.],
    [`plantilla/recursos/`], [Logos y marca de agua oficiales.],
    [`plantilla/fuentes/`], [Liberation Sans, sustituto métrico de Arial para equipos sin Arial.],
    [`plantilla/graficas/`], [Módulo Python con el estilo común de gráficas.],
    [`documentos/<CÓDIGO>/`], [Una carpeta por documento: `<CÓDIGO>.typ`, `figuras/`, `datos/` y el PDF.],
  ),
  caption: [Organización de archivos.],
)

Se compila desde la carpeta raíz del paquete:

```
typst compile --root . --font-path plantilla/fuentes documentos/ALM-FMT-01/ALM-FMT-01.typ documentos/ALM-FMT-01/ALM-FMT-01_Rev-0.1.pdf
```

Para trabajar con vista previa en vivo se recomienda VS Code con la extensión Tinymist, abriendo la carpeta raíz del paquete.

= Página, cajetín y pie

La hoja es A4 vertical. Un marco de 0.8 pt a 10 mm del borde encierra la página. En la parte superior del marco, en todas las hojas, va el cajetín de la @tab:cajetin, con el logo cuadrado a la izquierda. El pie, dentro del marco, repite código, revisión y estado a la izquierda y «PROYECTO ALIMOCHE» a la derecha. La marca de agua es el sello circular aclarado, centrado y de 125 mm.

#figure(
  table(
    columns: (40mm, 1fr),
    align: (left, left),
    [Campo], [Contenido],
    [Documento], [Título del documento, sin código.],
    [Código], [Identificador del documento (p. ej. ALM-P00-A06).],
    [Revisión], [0.1, 0.2... durante la redacción; 1.0 en la primera aprobación.],
    [Hoja], [Hoja actual / total. Automático.],
    [Tipo], [Clase de documento: Pliego, Estudio auxiliar, Nota técnica, Norma interna...],
    [Creación / últ. revisión], [Fechas DD/MM/AAAA. Si coinciden se muestra una sola.],
    [Estado], [Borrador, En revisión, Aprobado u Obsoleto. La plantilla rechaza otros valores.],
    [Elaboración], [Autor o autores.],
    [Revisión técnica], [Persona que revisa el contenido; «Pendiente» hasta que se designe.],
    [Aprobación], [Nombre de quien aprueba y, solo si lo indica el responsable, su firma.],
  ),
  caption: [Campos del cajetín.],
) <tab:cajetin>

Los metadatos solo aparecen en el cajetín. El cuerpo no repite autor, fecha, revisión ni estado, y no lleva portada ni historial de revisiones. En la primera hoja, bajo el cajetín, se escribe únicamente el título centrado. El índice se añade (`indice: true`) solo si el documento supera unas seis hojas.

No se usan colores en el texto, las tablas ni el cajetín; el único relleno admitido es el gris claro de la cabecera de las tablas. La única excepción son las gráficas con varias series (@sec:graficas). Los logos no se deforman, recortan ni recolorean; dentro del cuerpo solo se usan cuando el propio logo es objeto del documento.

= Tipografía y redacción

#figure(
  table(
    columns: (1fr, 26mm, 1fr),
    align: (left, left, left),
    [Elemento], [Cuerpo], [Estilo],
    [Texto], [10 pt], [Arial, justificado, con guiones, interlineado 1.15 aprox.],
    [Título del documento], [14 pt], [Negrita, centrado, solo en la primera hoja],
    [Título nivel 1], [12 pt], [Negrita, numerado: «3 Página, cajetín y pie»],
    [Título nivel 2], [10.5 pt], [Negrita, numerado: «3.1 ...»],
    [Título nivel 3], [10 pt], [Negrita, sin número; uso excepcional],
    [Tablas], [9 pt], [Alineado a la izquierda, sin justificar],
    [Pies de tabla y figura], [8.5 pt], [Etiqueta en negrita: «Tabla 2.» / «Figura 1.»],
    [Fuente de datos], [8 pt], [Gris, bajo la tabla o figura],
    [Código y rutas], [8.5 pt], [Monoespaciada (Consolas o DejaVu Sans Mono)],
    [Ecuaciones], [10 pt], [New Computer Modern Math, numeradas a la derecha],
  ),
  caption: [Tipografía.],
)

La fuente es Arial. En equipos sin Arial, la plantilla usa Liberation Sans, que ocupa exactamente lo mismo, de modo que la paginación no cambia.

== Redacción

Se redacta en español, en impersonal o en primera del plural, con frases cortas y sin adornos. Cada apartado debe poder leerse sin consultar otros. Se evita la negrita salvo para la conclusión o cifra que importa en un párrafo. No se usan subsecciones para un único párrafo: como norma, dos niveles de título como máximo.

Los elementos con identificador propio (hipótesis ASM, requisitos REQ, criterios CRIT...) se presentan con su código, que habla por sí solo, sin numeración de apartado delante. Los códigos no llevan ceros sobrantes: ASM-01, REQ-12. Una vez publicados, no se renumeran.

#item("ASM-01", "Entorno de vuelo (ejemplo)")[
  Aeródromo de Lillo (LELT), cota 681 m, 40 °C, densidad #q(1.04, "kg/m³", dec: 2). Así se escribe cualquier hipótesis, requisito o criterio identificado.
]

#nota[Las notas aclaran algo sin interrumpir el razonamiento. Se usan poco.]

#pendiente[Los asuntos abiertos se marcan así, para que se vean al revisar. Un documento aprobado no debe contener ninguno.]

== Números, unidades y fechas

Se usa *punto decimal* (#num(1.04, dec: 2)) y el sistema internacional, en texto, tablas, ecuaciones y gráficas. Los números de cinco o más cifras se agrupan de tres en tres con un espacio fino (#num(15690)); los de cuatro, no (#num(1569)). Nunca se usa la coma ni el punto como separador de millares. Entre número y unidad va siempre un espacio no separable: #q(160, "kg"), #q(9.81, "m/s²", dec: 2), #q(40, "°C"). La excepción es el porcentaje pegado al número cuando va en tabla o en paréntesis breve.

En la plantilla, `#num(x, dec: n)` y `#q(x, "unidad", dec: n)` hacen esto automáticamente y fijan el número de decimales.

Las fechas se escriben DD/MM/AAAA. Las magnitudes en cabeceras de tabla y ejes de gráfica se escriben «Magnitud (unidad)»; las adimensionales, «(–)».

= Tablas

Las tablas llevan trazo negro de 0.5 pt en todas las celdas, cabecera en negrita sobre gris claro y texto de 9 pt. El título va *encima*: «Tabla n. Texto». La fuente, si procede, va debajo. El texto se alinea a la izquierda y las cifras a la derecha, con el mismo número de decimales en toda la columna. Cada tabla se cita en el texto antes de aparecer.

Una tabla puede escribirse directamente en Typst (@tab:cajetin) o leerse de un CSV exportado desde Excel, como la @tab:masas. El CSV se guarda en `datos/` tal como sale de Excel y no se toca a mano: si cambian los datos, se vuelve a exportar. Si Excel está en español y exporta con «;» y coma decimal, `coma-a-punto: true` convierte las cifras al punto decimal al componer la tabla.

#figure(
  tabla-csv(csv("datos/masas_ejemplo.csv", delimiter: ";"), coma-a-punto: true, columnas: (1fr, 30mm, 30mm)),
  caption: [Desglose de masas de ejemplo leído de `datos/masas_ejemplo.csv`.],
) <tab:masas>
#fuente[valores ilustrativos; no constituyen un presupuesto de masas de ALIMOCHE.]

Las tablas largas pueden partirse entre hojas; la cabecera se repite sola. No se usan celdas combinadas salvo que sean imprescindibles.

= Figuras y gráficas

Toda imagen, esquema o gráfica es una figura numerada con su pie *debajo*: «Figura n. Texto». El pie describe lo que se ve y, si procede, la fuente o las condiciones del cálculo. La figura se cita en el texto antes de aparecer.

== Gráficas <sec:graficas>

Las gráficas se generan con Python y el módulo `plantilla/graficas/alimoche_graficas.py`, que fija el estilo: rejilla suave, sin marco superior ni derecho, punto decimal y texto en la fuente del documento.

Una gráfica con una sola curva va en negro y trazo continuo. Con varias curvas se admite color, pero *siempre combinado* con un tipo de trazo distinto (continuo, discontinuo, trazo y punto, punteado) y, a partir de la quinta serie, con marcador. Así la gráfica se lee igual impresa en blanco y negro. El módulo da esas combinaciones en orden con `serie(0)`, `serie(1)`...; `serie(i, color=False)` da la variante en negro y gris. Las barras van en grises; si se colorean, llevan además trama. Se guardan en SVG, que se ve nítido a cualquier escala. La gráfica no lleva título interno: el título es el pie de figura.

Cada gráfica tiene su script en `figuras/` y lee sus datos de `datos/` o los calcula. Así, cualquiera puede regenerarla. El ancho normal es 160 mm (completo) o 78 mm (media columna, dos lado a lado). La @fig:polar es el ejemplo de referencia.

#figure(
  image("figuras/polar_ejemplo.svg", width: 100%),
  caption: [Polar parabólica de ejemplo, $C_D = C_(D 0) + k C_L^2$ con $C_(D 0) = 0.055$, para tres valores del factor de Oswald. Cada serie combina color y tipo de trazo. La línea vertical de trazos marca el $C_(L,max)$ supuesto.],
) <fig:polar>

== Imágenes y fotografías

Las fotografías van en JPG y los esquemas en SVG o PNG, con resolución suficiente para imprimirse a su tamaño (unos 300 ppp). Se citan el autor o la procedencia en el pie. Las imágenes de terceros solo se usan si se puede indicar su origen. La @fig:logo muestra el tratamiento de una imagen.

#figure(
  image("figuras/logo_ejemplo.jpeg", width: 70mm),
  caption: [Ejemplo de imagen insertada a ancho fijo. Fuente: recursos gráficos de ALIMOCHE.],
) <fig:logo>

= Ecuaciones

Las ecuaciones que se citan van aparte y numeradas a la derecha; las breves pueden ir dentro del texto, como $q = 1/2 rho V^2$. Las variables se definen la primera vez que aparecen, justo después de la ecuación.

$ C_D = C_(D 0) + k C_L^2, quad k = 1 / (pi "AR" e) $ <eq:polar>

donde $C_(D 0)$ es la resistencia parásita, $"AR"$ el alargamiento y $e$ el factor de Oswald. La @eq:polar es la base de la @fig:polar.

= Estados, revisiones y nombre de los archivos

Un documento nace en «Borrador» con revisión 0.1 y sube a 0.2, 0.3... con cada versión que se comparte. Pasa a «En revisión» cuando se entrega a un revisor, y a «Aprobado», con revisión 1.0, solo cuando el responsable lo aprueba expresamente. Cambiar el estado en el archivo no es aprobarlo. Las revisiones posteriores a la aprobación son 1.1, 1.2... y la siguiente aprobación, 2.0. Un documento sustituido pasa a «Obsoleto».

Provisionalmente, el original se llama `<CÓDIGO>.typ` y el PDF `<CÓDIGO>_Rev-<n.n>.pdf` (por ejemplo `ALM-P00-A06_Rev-0.3.pdf`). El documento de estructura documental podrá cambiar esta regla.

#pendiente[Árbol documental, asignación de códigos, relación padre-hijo y nombres definitivos de archivos: se fijarán en un documento posterior.]

= Conversión de documentos existentes

Un estudio redactado en Word, o un PDF hecho con otra herramienta, se convierte así: se extrae el texto, las tablas, las ecuaciones y las imágenes; se reorganiza el contenido según esta norma sin alterar datos, conclusiones ni identificadores; y se compone en Typst con la plantilla. Las gráficas que se puedan regenerar a partir de datos se rehacen con el módulo común; las que no, se conservan como imagen. Lo que falte o sea dudoso se marca como pendiente en lugar de inventarse. El procedimiento detallado para la IA está en `INSTRUCCIONES_IA.md`.

#referencias((
  [Typst. _Typst documentation_, versión 0.15. https://typst.app/docs],
  [ALIMOCHE. ALM-P00-A06 _Estimación aerodinámica preliminar_, Rev. 0.2, 25/10/2026.],
))

#show: anexos

= Resumen de funciones de la plantilla

#figure(
  table(
    columns: (58mm, 1fr),
    align: (left, left),
    [Función], [Uso],
    [`#show: documento.with(...)`], [Cabecera de todo documento: código, título, tipo, revisión, estado, fechas, autor, revisor, aprobación, índice.],
    [`= Título` / `== Título`], [Títulos de nivel 1 y 2, numerados.],
    [`#item("REQ-01", "Título")[...]`], [Hipótesis, requisito o criterio con identificador.],
    [`#nota[...]`, `#pendiente[...]`], [Nota aclaratoria; asunto abierto.],
    [`#num(x, dec: n)`, `#q(x, "u", dec: n)`], [Número con punto decimal y millares con espacio; cantidad con unidad.],
    [`#figure(table(...), caption: [...]) <tab:x>`], [Tabla numerada; citar con `@tab:x`.],
    [`#tabla-csv(csv("datos/x.csv"))`], [Tabla desde un CSV de Excel (`coma-a-punto: true` si viene con coma decimal).],
    [`#figure(image("figuras/x.svg"), caption: [...]) <fig:x>`], [Figura numerada; citar con `@fig:x`.],
    [`#fuente[...]`], [Línea «Fuente: ...» bajo tabla o figura.],
    [`$ ... $ <eq:x>`], [Ecuación numerada; citar con `@eq:x`.],
    [`#referencias((...))`], [Lista final de referencias [1], [2]...],
    [`#show: anexos`], [A partir de ahí, los títulos son «Anexo A», «Anexo B».],
  ),
  caption: [Funciones de la plantilla.],
)
