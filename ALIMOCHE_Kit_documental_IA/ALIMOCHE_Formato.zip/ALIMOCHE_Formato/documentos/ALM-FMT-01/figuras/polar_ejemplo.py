"""Figura de ejemplo para ALM-FMT-01: polar parabólica (valores de ALM-P00-A06 Rev. 0.2)."""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[3] / "plantilla" / "graficas"))
import alimoche_graficas as ag
import numpy as np

CD0, k = 0.055, 0.0455
CL = np.linspace(0, 1.5, 61)
fig, ax = ag.figura(160, 72)
ax.plot(CL, CD0 + k * CL**2, **ag.serie(0), label="e = 0.70 (caso base)")
ax.plot(CL, CD0 + 0.8 * k * CL**2, **ag.serie(1), label="e = 0.875 (sensibilidad)")
ax.plot(CL, CD0 + 0.7 * k * CL**2, **ag.serie(2), label="e = 1.00 (ala elíptica ideal)")
ax.axvline(1.5, **ag.LIMITE)
CLopt = (CD0 / k) ** 0.5
ax.plot([CLopt], [2 * CD0], marker="o", markersize=4, color="black", markerfacecolor="white", linestyle="none")
ag.anotar(ax, "Fineza máxima (caso base)", (CLopt, 2 * CD0), (0.72, 0.035))
ax.set_xlabel("Coeficiente de sustentación $C_L$ (–)")
ax.set_ylabel("Coeficiente de resistencia $C_D$ (–)")
ax.set_xlim(0, 1.6); ax.set_ylim(0, 0.17)
ag.leyenda(ax, loc="upper left")
ag.guardar(fig, __file__)
