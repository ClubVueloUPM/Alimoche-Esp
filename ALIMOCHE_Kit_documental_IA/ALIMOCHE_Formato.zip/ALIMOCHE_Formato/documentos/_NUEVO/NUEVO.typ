// Esqueleto de documento ALIMOCHE.
// 1) Copiar la carpeta _NUEVO como documentos/<CÓDIGO>/ y renombrar este archivo a <CÓDIGO>.typ
// 2) Rellenar los metadatos (solo aquí; la plantilla los lleva al cajetín)
// 3) Compilar desde la raíz del paquete:
//    typst compile --root . --font-path plantilla/fuentes documentos/<CÓDIGO>/<CÓDIGO>.typ documentos/<CÓDIGO>/<CÓDIGO>_Rev-0.1.pdf
#import "../../plantilla/alimoche.typ": *

#show: documento.with(
  codigo: "ALM-XX",
  titulo: "Título del documento",
  tipo: "Estudio auxiliar",        // Pliego · Estudio auxiliar · Nota técnica · Norma interna · Guía ...
  revision: "0.1",
  estado: "Borrador",              // Borrador · En revisión · Aprobado · Obsoleto
  creado: "DD/MM/AAAA",
  modificado: none,                // fecha de la última revisión; none = igual a «creado»
  autor: "Nombre Apellido",
  revisor: "Pendiente",
  aprobacion: "Pendiente",
  indice: false,                   // true si el documento supera unas 6 hojas
)

= Objeto y alcance

Qué pregunta responde el documento, de qué documentos parte y qué entrega.

= Datos de entrada

#figure(
  table(
    columns: (1fr, 30mm, 1fr),
    align: (left, right, left),
    [Magnitud], [Valor], [Procedencia],
    [Masa en vacío objetivo], [#q(70, "kg")], [ALM-00],
  ),
  caption: [Datos de entrada.],
) <tab:entradas>

= Desarrollo

Texto. Citar tablas y figuras antes de que aparezcan: @tab:entradas.

#item("ASM-01", "Título de la hipótesis")[
  Enunciado de la hipótesis.
]

// #figure(image("figuras/grafica.svg", width: 100%), caption: [Descripción.]) <fig:grafica>

= Conclusiones

Resultados que salen del documento y a qué documentos alimentan.

#referencias((
  [Autor. _Título_. Editorial o enlace, año.],
))

// #show: anexos
// = Título del anexo
