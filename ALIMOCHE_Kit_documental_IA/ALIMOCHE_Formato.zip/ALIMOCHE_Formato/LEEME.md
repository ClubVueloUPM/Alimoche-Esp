# ALIMOCHE · Kit de formato documental (Typst)

**Versión del kit:** 28/10/2026 (rev. 2: punto decimal, color en gráficas) · Typst 0.15.1

Existe una versión equivalente íntegramente en inglés: `ALIMOCHE_Format_EN.zip`.

Este paquete fija **el formato** de los documentos de ALIMOCHE y permite que una IA en un chat nuevo convierta un Word de investigación en un documento ALIMOCHE (`.typ` + PDF). La **estructura documental** (árbol, códigos, nombres definitivos) queda para un documento posterior.

## Contenido

```text
LEEME.md                    este archivo
INSTRUCCIONES_IA.md         lo que lee la IA: flujo Word -> Typst -> PDF, reglas y comprobaciones
plantilla/
  alimoche.typ              plantilla común (marco, cajetín, estilos, funciones). No se edita por documento
  recursos/                 logos y marca de agua
  fuentes/                  Liberation Sans (sustituto métrico de Arial)
  graficas/alimoche_graficas.py   estilo común de gráficas (matplotlib -> SVG)
documentos/
  ALM-FMT-01/               norma de formato: .typ, PDF, gráfica de ejemplo con su script, CSV de ejemplo
  _NUEVO/                   esqueleto para empezar un documento
herramientas/
  compilar.sh / compilar.ps1     compilan un documento por su código
  typst-0.15.1-linux-x86_64.tar.xz   Typst para el entorno Linux de la IA
```

## Uso con una IA

1. En un chat o proyecto nuevo, adjunta `ALIMOCHE_Formato.zip` y tu Word.
2. Pega el texto del apartado «Texto para pegar en el chat» de `INSTRUCCIONES_IA.md`, con código, título, tipo, autor y fecha.
3. La IA devuelve un ZIP con `documentos/<CÓDIGO>/` y el PDF. Copia esa carpeta dentro de tu `documentos/`.

## Uso en tu equipo (Windows)

1. Typst 0.15.1 (`typst.exe` en el PATH) y, para editar con vista previa, VS Code + extensión **Tinymist**. Abre en VS Code la carpeta `ALIMOCHE_Formato` (la raíz, no la del documento).
2. Compila: `.\herramientas\compilar.ps1 ALM-P00-A06` → `documentos\ALM-P00-A06\ALM-P00-A06_Rev-0.2.pdf`.
3. Para un documento nuevo, copia `documentos\_NUEVO` como `documentos\<CÓDIGO>` y renombra el `.typ`.

## Qué decide este kit y qué no

- **Fijado:** página A4 con marco, cajetín en todas las hojas, marca de agua, pie, Arial 10 pt justificado, dos niveles de título numerados, identificadores ASM/REQ/CRIT como bloque propio, tablas en negro con cabecera gris claro, pies «Tabla n.» arriba y «Figura n.» abajo, gráficas desde Python (negro; color solo con varias series y siempre combinado con tipo de trazo), punto decimal, ecuaciones numeradas, sin portada ni historial ni colores en el resto.
- **Provisional:** el código `ALM-FMT-01` de la norma y el nombre de archivo `<CÓDIGO>_Rev-<n.n>.pdf`.
- **Pendiente (documento 2):** árbol documental, asignación de códigos, padre/dependencias, nombres definitivos.
